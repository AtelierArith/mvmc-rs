#!/usr/bin/env bash
# Optional profiler extraction; no packages are installed in the system.
set -euo pipefail
mkdir /tmp/mvmc-587-profiler-reproduce
cd /tmp/mvmc-587-profiler-reproduce
apt-get download nsight-systems-target=2022.4.2.50~12.0.1-4build4 nsight-systems=2022.4.2.50~12.0.1-4build4
dpkg-deb -x nsight-systems-target_*.deb extracted
dpkg-deb -x nsight-systems_*.deb extracted
mkdir compat
ln -s /lib/x86_64-linux-gnu/libssh.so.4 compat/libssh.so
# Original capture flags: nsys profile --sample=none --cpuctxsw=none --trace=cuda,osrt --output=trace taskset -c 0 BINARY namelist.def zqp_opt.dat
# Original offline import/stats used LD_LIBRARY_PATH=/tmp/mvmc-587-profiler/compat.
# Use benchmark/gpu_physcal_l128/profile.sh with the extracted nsys and QdstrmImporter paths.
