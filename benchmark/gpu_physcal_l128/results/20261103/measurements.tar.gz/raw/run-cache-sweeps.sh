#!/usr/bin/env bash
set -euo pipefail
export CUDA_VISIBLE_DEVICES=1
export LD_LIBRARY_PATH=/tmp/mvmc-570-cuda-env/lib/python3.12/site-packages/cutensor/lib:/home/terasaki/.julia/artifacts/369f5472daa95aec77a8de76aa620f1b8f13293f/lib:/home/terasaki/.julia/artifacts/6b0fef1d16bb8733a19f60c6efec768f99e5f90d/lib
bench_common=(--binary /tmp/mvmc-587-native-target/release/mvmc-cuda --input /tmp/mvmc-587-physcal/benchmark/cpu_scaling_l128/inputs/phys)
export MVMC_RS_CUDA_KERNEL_CACHE=off
uv run --no-project python /tmp/mvmc-587-evidence/measure_gpu.py "${bench_common[@]}" --out /tmp/mvmc-587-evidence/cache-disabled > /tmp/mvmc-587-evidence/cache-disabled.log 2>&1
uv run --no-project python /tmp/mvmc-587-evidence/measure_gpu.py "${bench_common[@]}" --cold-cache --out /tmp/mvmc-587-evidence/cache-cold > /tmp/mvmc-587-evidence/cache-cold.log 2>&1
export MVMC_RS_CUDA_KERNEL_CACHE=/tmp/mvmc-587-evidence/reused-kernel-cache
uv run --no-project python /tmp/mvmc-587-evidence/measure_gpu.py "${bench_common[@]}" --out /tmp/mvmc-587-evidence/cache-hit > /tmp/mvmc-587-evidence/cache-hit.log 2>&1
