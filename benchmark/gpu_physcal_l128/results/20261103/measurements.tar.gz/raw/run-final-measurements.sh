#!/usr/bin/env bash
set -euo pipefail
export CUDA_VISIBLE_DEVICES=1
export LD_LIBRARY_PATH=/tmp/mvmc-570-cuda-env/lib/python3.12/site-packages/cutensor/lib:/home/terasaki/.julia/artifacts/369f5472daa95aec77a8de76aa620f1b8f13293f/lib:/home/terasaki/.julia/artifacts/6b0fef1d16bb8733a19f60c6efec768f99e5f90d/lib
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 BLIS_NUM_THREADS=1 MVMC_RS_CUDA_RNG=sfmt
bench_common=(--binary /tmp/mvmc-587-native-target/release/mvmc-cuda --input /tmp/mvmc-587-physcal/benchmark/cpu_scaling_l128/inputs/phys)
export MVMC_RS_CUDA_KERNEL_CACHE=off
uv run --no-project python benchmark/gpu_physcal_l128/measure.py "${bench_common[@]}" --out /tmp/mvmc-587-evidence/final-disabled > /tmp/mvmc-587-evidence/final-disabled.log 2>&1
uv run --no-project python benchmark/gpu_physcal_l128/measure.py "${bench_common[@]}" --cold-cache --out /tmp/mvmc-587-evidence/final-cold > /tmp/mvmc-587-evidence/final-cold.log 2>&1
export MVMC_RS_CUDA_KERNEL_CACHE=/tmp/mvmc-587-evidence/final-reused-kernel-cache
uv run --no-project python benchmark/gpu_physcal_l128/measure.py "${bench_common[@]}" --out /tmp/mvmc-587-evidence/final-hit > /tmp/mvmc-587-evidence/final-hit.log 2>&1
bench_input=/tmp/mvmc-587-physcal/benchmark/cpu_scaling_l128/inputs/phys
export MVMC_RS_SR_BACKEND=c-order MVMC_RS_MEASURE_PF_BACKEND=c-order MVMC_RS_MEASURE_BACKEND=c-order MVMC_RS_SAMPLER_BACKEND=c-order
for bench_n in 1 4 8 16; do
 export RAYON_NUM_THREADS=$bench_n MVMC_RS_INNER_THREADS=$bench_n
 taskset -c "0-$((bench_n-1))" /tmp/mvmc-587-native-target/release/examples/physcal_warm_587 "$bench_input/namelist.def" "$bench_input/zqp_opt.dat" "/tmp/mvmc-587-evidence/final-api-cpu-$bench_n" --no-output > "/tmp/mvmc-587-evidence/final-api-cpu-$bench_n.log" 2>&1
done
export RAYON_NUM_THREADS=1 MVMC_RS_INNER_THREADS=1
export MVMC_RS_SR_BACKEND=cuda MVMC_RS_MEASURE_PF_BACKEND=cuda MVMC_RS_MEASURE_BACKEND=cuda MVMC_RS_SAMPLER_BACKEND=cuda
taskset -c 0 /tmp/mvmc-587-native-target/release/examples/physcal_warm_587 "$bench_input/namelist.def" "$bench_input/zqp_opt.dat" /tmp/mvmc-587-evidence/final-api-gpu --no-output > /tmp/mvmc-587-evidence/final-api-gpu.log 2>&1
taskset -c 0 /tmp/mvmc-587-native-target/release/examples/physcal_warm_587 "$bench_input/namelist.def" "$bench_input/zqp_opt.dat" /tmp/mvmc-587-evidence/final-api-gpu-files > /tmp/mvmc-587-evidence/final-api-gpu-files.log 2>&1
