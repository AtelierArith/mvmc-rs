#!/usr/bin/env bash
# Recorded checks; output paths are historical and must be changed for a new run.
set -euo pipefail
export CARGO_TARGET_DIR=/tmp/mvmc-587-native-target
export CUDA_VISIBLE_DEVICES=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 RAYON_NUM_THREADS=1
export LD_LIBRARY_PATH=/tmp/mvmc-570-cuda-env/lib/python3.12/site-packages/cutensor/lib:/home/terasaki/.julia/artifacts/369f5472daa95aec77a8de76aa620f1b8f13293f/lib:/home/terasaki/.julia/artifacts/6b0fef1d16bb8733a19f60c6efec768f99e5f90d/lib
cargo nextest run --locked -p mvmc-core -E 'test(nested_decision_capture)'
cargo nextest run --locked -p mvmc-core --test device_sampler
cargo clippy --locked -p mvmc-core --all-targets -- -D warnings
cargo nextest run --locked --manifest-path gpu/mvmc-gpu-cuda/Cargo.toml --lib --run-ignored all -E 'test(kernel_cache::tests)'
MVMC_RS_CUDA_GATE=1 MVMC_RS_SR_BACKEND=c-order MVMC_RS_CUDA_KERNEL_CACHE=/tmp/mvmc-587-evidence/regression-kernel-cache cargo nextest run --locked --manifest-path gpu/mvmc-gpu-cuda/Cargo.toml --test measurement_gate --test sr_routing_gate --test sampler_production_gate --run-ignored all --test-threads 1 --no-fail-fast --retries 0
cargo clippy --locked --manifest-path gpu/mvmc-gpu-cuda/Cargo.toml --all-targets -- -D warnings
cargo fmt --all --check
cargo fmt --manifest-path gpu/mvmc-gpu-cuda/Cargo.toml --all --check
