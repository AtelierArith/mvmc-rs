"""Independent saved-output comparison, separate from performance runs."""
import json,math
from pathlib import Path
base=Path('/tmp/mvmc-586-final-c-order-20261103/phys-rust-t1-r1/output')
root=Path('/tmp/mvmc-587-evidence'); names=['zvo_out_001.dat','zvo_cisajs_001.dat','zvo_cisajscktalt_001.dat']; rows=[]
for folder in sorted(folder for cohort in ['gpu-before','cache-disabled','cache-cold','cache-hit'] for folder in (root/cohort).glob('rep*/output')):
 count=0; worst=0
 for name in names:
  expected=(base/name).read_text().split(); actual=(folder/name).read_text().split(); assert len(expected)==len(actual),(folder,name)
  for x,y in zip(expected,actual):
   x=float(x); y=float(y); assert math.isfinite(x) and math.isfinite(y)
   diff=abs(x-y); assert diff<=1e-11+1e-11*max(abs(x),abs(y)), (folder,name,x,y)
   count+=1; worst=max(worst,diff)
 rows.append({'run':str(folder.relative_to(root)),'numeric_tokens':count,'max_absolute_difference':worst})
(root/'output-comparison.json').write_text(json.dumps({'reference':str(base),'bound':'abs + rel: 1e-11 + 1e-11 max(abs(x),abs(y)); numerical only; exact RNG tested separately','rows':rows},indent=2)+'\n')
print(json.dumps(rows,indent=2))
