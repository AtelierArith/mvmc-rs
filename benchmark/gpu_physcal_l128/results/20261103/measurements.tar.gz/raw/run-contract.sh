#!/usr/bin/env bash
set -euo pipefail
export CUDA_VISIBLE_DEVICES=1
export LD_LIBRARY_PATH=/tmp/mvmc-570-cuda-env/lib/python3.12/site-packages/cutensor/lib:/home/terasaki/.julia/artifacts/369f5472daa95aec77a8de76aa620f1b8f13293f/lib:/home/terasaki/.julia/artifacts/6b0fef1d16bb8733a19f60c6efec768f99e5f90d/lib
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 RAYON_NUM_THREADS=1 MVMC_RS_INNER_THREADS=1
export MVMC_RS_CUDA_KERNEL_CACHE=/tmp/mvmc-587-evidence/reused-kernel-cache
bench_args=(/tmp/mvmc-587-physcal/benchmark/cpu_scaling_l128/inputs/phys/namelist.def /tmp/mvmc-587-physcal/benchmark/cpu_scaling_l128/inputs/phys/zqp_opt.dat)
export MVMC_RS_SR_BACKEND=cuda MVMC_RS_MEASURE_PF_BACKEND=cuda MVMC_RS_MEASURE_BACKEND=cuda MVMC_RS_SAMPLER_BACKEND=cuda
taskset -c 0 /tmp/mvmc-587-native-target/release/examples/physcal_warm_587 "${bench_args[@]}" /tmp/mvmc-587-evidence/contract-gpu --contract > /tmp/mvmc-587-evidence/contract-gpu.log 2>&1
export MVMC_RS_SR_BACKEND=c-order MVMC_RS_MEASURE_PF_BACKEND=c-order MVMC_RS_MEASURE_BACKEND=c-order MVMC_RS_SAMPLER_BACKEND=c-order
taskset -c 0 /tmp/mvmc-587-native-target/release/examples/physcal_warm_587 "${bench_args[@]}" /tmp/mvmc-587-evidence/contract-cpu --contract > /tmp/mvmc-587-evidence/contract-cpu.log 2>&1
