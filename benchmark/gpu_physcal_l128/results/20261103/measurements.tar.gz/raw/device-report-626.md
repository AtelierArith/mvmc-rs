## CUDA gate report

```
backend=cuda:0
device=NVIDIA GeForce RTX 3060
compute_capability=CudaComputeCapability { major: 8, minor: 6 }
total_memory_bytes=12486246400
driver_version=580.178.04
cuda_driver_api=13.0
nvrtc_version=12.8
cublas_version=12.8.4
cusolver_version=11.7.3
tenferro_version=0.8.0
```

median of 1 runs after 1 warm-up, milliseconds; tolerances: dot 1e-11, cholesky 1e-10 (relative max-norm vs tenferro CPU)

| op | dtype | n | CPU compute | CUDA upload | CUDA compute | CUDA download | CPU/CUDA compute | rel err | tol | check |
|---|---|---|---|---|---|---|---|---|---|---|
| Dot | F64 | 16 | 0.020 | 0.115 | 0.105 | 0.062 | 0.19x | 0.00e0 | 1e-11 | ok |
| Dot | C64 | 16 | 0.024 | 0.098 | 0.098 | 0.040 | 0.24x | 3.57e-16 | 1e-11 | ok |
| Cholesky | F64 | 16 | 0.018 | 0.076 | 2.296 | 0.055 | 0.01x | 0.00e0 | 1e-10 | ok |
| Cholesky | C64 | 16 | 0.018 | 0.055 | 2.098 | 0.055 | 0.01x | 1.08e-16 | 1e-10 | ok |
