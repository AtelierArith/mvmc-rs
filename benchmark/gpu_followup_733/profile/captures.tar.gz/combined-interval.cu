// Sticky resident status word (#573). The first failing stage wins via
// atomicCAS(error, 0, code); later kernels observe a nonzero word and return.
// Keep these values identical to `ResidentFailure::from_status` in
// src/interval/resident.rs (checked by a host unit test).
#ifndef MVMC_RESIDENT_STATUS
#define MVMC_RESIDENT_STATUS
enum {
  RESIDENT_REBUILD = 1,      // singular/nonfinite QP plane or zero/nonfinite overlap
  RESIDENT_ENERGY = 2,       // nonfinite local energy or observable
  RESIDENT_SR = 3,           // SR Cholesky failure
  RESIDENT_PARAMETERS = 4,   // nonfinite parameter update
  RESIDENT_SCHEDULE = 5,     // a walker did not finish its scheduled hops
  RESIDENT_DERIVATIVES = 6,  // nonfinite log-derivative
  RESIDENT_CG = 7,           // nonfinite SR-CG increment (C StcOpt info=1)
  RESIDENT_CG_FAILED = 8,    // SR-CG solve failed with NSRCGAbortOnFail (C 1.4.0 MPI_Abort)
};
#endif

// Panelized Parlett-Reid Pfaffian, following the delayed rank-two update
// organization of tensor4all/faer (Wimmer Algorithm 923). A CUDA block owns
// one matrix. Eliminated columns hold panel factors, so caller scratch and
// host/device transfers do not grow. This is a device implementation, not a
// call to faer's CPU-only API.
#ifndef MVMC_PFAFFIAN_PANEL
#define MVMC_PFAFFIAN_PANEL

template <typename Ops, bool Factor = false>
__device__ typename Ops::T resident_panel_pfaffian(
    typename Ops::T* A, int n, typename Ops::T* tau, typename Ops::T* u,
    typename Ops::T* lower = nullptr, typename Ops::T* diagonal = nullptr,
    int* permutation = nullptr, int* factor_status = nullptr) {
  typedef typename Ops::T T;
  __shared__ T product;
  const int tid = threadIdx.x, nt = blockDim.x;
  if (tid == 0) product = Ops::one();
  if (Factor) {
    if (tid == 0) *factor_status = 0;
    for (int i=tid;i<n;i+=nt) permutation[i]=i;
    for (int i=tid;i<n*n;i+=nt) lower[i] = i%n==i/n ? Ops::one() : Ops::zero();
  }
  __syncthreads();
  if (n & 1) return Ops::zero();
  const int panel = 8;
  for (int start = 0; start < n; start += panel) {
    const int end = min(start + panel, n);
    for (int k = start; k + 1 < end; k += 2) {
      // Materialize only this pivot column, with pending panel corrections.
      for (int r = k + 1 + tid; r < n; r += nt) {
        T value = A[r + (size_t)k * n];
        for (int p = start; p < k; p += 2) {
          value = Ops::add(value, Ops::sub(
              Ops::mul(A[r + (size_t)p*n], A[k + (size_t)(p+1)*n]),
              Ops::mul(A[r + (size_t)(p+1)*n], A[k + (size_t)p*n])));
        }
        tau[r] = value;
      }
      __syncthreads();
      const int kp = Ops::argmax(tau, k + 1, n);
      if (kp < 0) {
        if (tid == 0) product = kp == -1 ? Ops::zero() : Ops::nan();
        if (Factor && tid == 0) *factor_status = kp == -1 ? 1 : -1;
        __syncthreads();
        const T value = product;
        __syncthreads();
        return value;
      }
      // Store the current pivot column before its congruence permutation.
      for (int r = k + 1 + tid; r < n; r += nt) A[r + (size_t)k*n] = tau[r];
      __syncthreads();
      if (kp != k + 1) {
        for (int c = tid; c < n; c += nt) {
          const T x = A[k + 1 + (size_t)c*n];
          A[k + 1 + (size_t)c*n] = A[kp + (size_t)c*n];
          A[kp + (size_t)c*n] = x;
        }
        if (Factor) {
          for (int c=tid;c<k;c+=nt) {
            const T x=lower[k+1+(size_t)c*n];
            lower[k+1+(size_t)c*n]=lower[kp+(size_t)c*n];
            lower[kp+(size_t)c*n]=x;
          }
          if (tid==0) { const int p=permutation[k+1]; permutation[k+1]=permutation[kp]; permutation[kp]=p; }
        }
        __syncthreads();
        for (int r = tid; r < n; r += nt) {
          const T x = A[r + (size_t)(k+1)*n];
          A[r + (size_t)(k+1)*n] = A[r + (size_t)kp*n];
          A[r + (size_t)kp*n] = x;
        }
        if (tid == 0) product = Ops::neg(product);
        __syncthreads();
      }
      const T d = A[k + 1 + (size_t)k*n];
      if (tid == 0) product = Ops::mul(product, Ops::neg(d));
      if (Factor && tid==0) diagonal[k/2]=d;
      for (int r = k + 2 + tid; r < n; r += nt) {
        T value = A[r + (size_t)(k+1)*n];
        for (int p = start; p < k; p += 2) {
          value = Ops::add(value, Ops::sub(
              Ops::mul(A[r + (size_t)p*n], A[k+1 + (size_t)(p+1)*n]),
              Ops::mul(A[r + (size_t)(p+1)*n], A[k+1 + (size_t)p*n])));
        }
        u[r] = value;
        tau[r] = Ops::div(A[r + (size_t)k*n], d);
        if (Factor) {
          lower[r+(size_t)k*n]=Ops::neg(Ops::div(value,d));
          lower[r+(size_t)(k+1)*n]=tau[r];
        }
      }
      __syncthreads();
      for (int r = k + 2 + tid; r < n; r += nt) {
        A[r + (size_t)k*n] = tau[r];
        A[r + (size_t)(k+1)*n] = u[r];
      }
      __syncthreads();
    }
    // Fuse every pending pair into one read/write of each trailing entry.
    // Only one triangle is evaluated; the other is its exact negative.
    const int width = n - end;
    for (int index = tid; index < width * width; index += nt) {
      const int r = end + index % width, c = end + index / width;
      if (r <= c) continue;
      T value = A[r + (size_t)c*n];
      for (int p = start; p < end; p += 2) {
        value = Ops::add(value, Ops::sub(
            Ops::mul(A[r + (size_t)p*n], A[c + (size_t)(p+1)*n]),
            Ops::mul(A[r + (size_t)(p+1)*n], A[c + (size_t)p*n])));
      }
      A[r + (size_t)c*n] = value;
      A[c + (size_t)r*n] = Ops::neg(value);
    }
    __syncthreads();
  }
  const T value = product;
  __syncthreads();
  return value;
}
#endif

// Block-cooperative dense helpers for singular QP planes (#573).
//
// Julia GPU recovers per plane (Julia-mVMC 7314015): walkers with an invalid
// plane use full Pfaffians for proposals and observables
// (cuda_cooperative_sampling.jl:3-22, cuda_observables.jl:283-295), rebuild
// in the hop kernel (cuda_observables.jl:355-450), and use exact (n-2)-minor
// Pfaffians for derivatives (cuda_sr.jl:154-187). These helpers run on one
// block, keep matrices in per-walker global scratch and need two n-vectors of
// shared or global scratch. They serve only walkers with an invalid plane;
// the all-valid path keeps its inverse-update arithmetic.
//
// Matrices are column-major, A(r,c) = A[r + c*n], as gathered by
// interval_resident_factor: A[i*n + j] = -S[q][rs_i][rs_j].
#ifndef MVMC_RESIDENT_DENSE
#define MVMC_RESIDENT_DENSE
#ifndef SLT
#define SLT(tab, qp, row, col, n2) ((tab)[(((size_t)(qp) * (n2)) + (row)) * (n2) + (col)])
#endif

// Gather the skew plane of global sites rs[0..n), omitting electron slots
// `skip_a` and `skip_b` (pass -1 to keep all). Returns the gathered side.
__device__ inline int resident_gather(double* A, const int* rs, int n, int skip_a, int skip_b,
                                      const double* slater, int q, int n2) {
  const int m = n - (skip_a >= 0) - (skip_b >= 0);
  for (int index = threadIdx.x; index < m * m; index += blockDim.x) {
    int r = index % m, c = index / m;
    // Map the minor index back to the electron slot, skipping removed slots.
    r += (skip_a >= 0 && r >= skip_a);
    r += (skip_b >= 0 && r >= skip_b);
    c += (skip_a >= 0 && c >= skip_a);
    c += (skip_b >= 0 && c >= skip_b);
    A[index] = -SLT(slater, q, rs[c], rs[r], n2);
  }
  __syncthreads();
  return m;
}

// First index of the largest |x[i]| over begin <= i < end, reduced by the
// whole block (blockDim a multiple of 32). Ties keep the smallest index, as a
// serial scan does. Returns -1 when every entry is zero and -2 when any entry
// is nonfinite, so a NaN can never be mistaken for a singular pivot.
__device__ int resident_block_argmax(const double* x, int begin, int end) {
  __shared__ double s_value[32];
  __shared__ int s_index[32];
  const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5;
  const int warps = blockDim.x >> 5;
  double best = -1.0;
  int index = end, nonfinite = 0;
  for (int i = begin + tid; i < end; i += blockDim.x) {
    const double v = fabs(x[i]);
    nonfinite |= !isfinite(v);
    if (v > best) {
      best = v;
      index = i;
    }
  }
  for (int d = 16; d; d >>= 1) {
    const double other = __shfl_down_sync(0xffffffff, best, d);
    const int at = __shfl_down_sync(0xffffffff, index, d);
    if (other > best || (other == best && at < index)) {
      best = other;
      index = at;
    }
  }
  if (lane == 0) {
    s_value[warp] = best;
    s_index[warp] = index;
  }
  nonfinite = __syncthreads_or(nonfinite);
  if (warp == 0) {
    best = lane < warps ? s_value[lane] : -1.0;
    index = lane < warps ? s_index[lane] : end;
    for (int d = 16; d; d >>= 1) {
      const double other = __shfl_down_sync(0xffffffff, best, d);
      const int at = __shfl_down_sync(0xffffffff, index, d);
      if (other > best || (other == best && at < index)) {
        best = other;
        index = at;
      }
    }
    if (lane == 0) s_index[0] = nonfinite ? -2 : (best > 0.0 ? index : -1);
  }
  __syncthreads();
  const int result = s_index[0];
  __syncthreads();
  return result;
}

// Pfaffian by skew Parlett-Reid elimination with row/column partial pivoting
// (PFAPACK pfaffian_LTL). An exactly zero pivot column gives Pf = 0; a
// nonfinite column gives NaN. The rank-two update uses separately rounded
// products, so A remains exactly skew-symmetric. Destroys A; tau and u hold n
// doubles each. Every thread of the block must call it and receives the same
// value.
__device__ double resident_block_pfaffian_unblocked(double* A, int n, double* tau, double* u) {
  __shared__ double s_pf;
  const int tid = threadIdx.x, nt = blockDim.x;
  if (tid == 0) s_pf = 1.0;
  __syncthreads();
  for (int k = 0; k + 1 < n; k += 2) {
    const int kp = resident_block_argmax(A + (size_t)k * n, k + 1, n);
    if (kp < 0) {
      if (tid == 0) s_pf = kp == -1 ? 0.0 : __longlong_as_double(0x7ff8000000000000LL);
      __syncthreads();
      break;
    }
    if (kp != k + 1) {
      for (int c = tid; c < n; c += nt) {
        const double x = A[(k + 1) + (size_t)c * n];
        A[(k + 1) + (size_t)c * n] = A[kp + (size_t)c * n];
        A[kp + (size_t)c * n] = x;
      }
      __syncthreads();
      for (int r = tid; r < n; r += nt) {
        const double x = A[r + (size_t)(k + 1) * n];
        A[r + (size_t)(k + 1) * n] = A[r + (size_t)kp * n];
        A[r + (size_t)kp * n] = x;
      }
      if (tid == 0) s_pf = -s_pf;
      __syncthreads();
    }
    const double pivot = A[k + (size_t)(k + 1) * n];
    if (tid == 0) s_pf = __dmul_rn(s_pf, pivot);
    for (int c = k + 2 + tid; c < n; c += nt) {
      tau[c] = __ddiv_rn(A[k + (size_t)c * n], pivot);
      u[c] = A[c + (size_t)(k + 1) * n];
    }
    __syncthreads();
    const int width = n - k - 2;
    for (int index = tid; index < width * width; index += nt) {
      const int r = k + 2 + index % width, c = k + 2 + index / width;
      const double delta = __dsub_rn(__dmul_rn(tau[r], u[c]), __dmul_rn(u[r], tau[c]));
      A[r + (size_t)c * n] = __dadd_rn(A[r + (size_t)c * n], delta);
    }
    __syncthreads();
  }
  const double result = s_pf;
  __syncthreads();
  return result;
}

struct ResidentRealPfOps {
  typedef double T;
  __device__ static T one() { return 1.0; }
  __device__ static T zero() { return 0.0; }
  __device__ static T nan() { return __longlong_as_double(0x7ff8000000000000LL); }
  __device__ static T neg(T x) { return -x; }
  __device__ static T add(T x, T y) { return __dadd_rn(x, y); }
  __device__ static T sub(T x, T y) { return __dsub_rn(x, y); }
  __device__ static T mul(T x, T y) { return __dmul_rn(x, y); }
  __device__ static T div(T x, T y) { return __ddiv_rn(x, y); }
  __device__ static int argmax(const T* x, int begin, int end) {
    return resident_block_argmax(x, begin, end);
  }
};

__device__ double resident_block_pfaffian(double* A, int n, double* tau, double* u) {
  // Structured proposal/observable matrices favor this loop: using the panel
  // here regressed L128 Opt by 7%, despite its dense standalone benchmark gain.
  // Shared-factor full rebuilds select panels separately in pfaffian_batched.cu.
  return resident_block_pfaffian_unblocked(A, n, tau, u);
}

// Gauss-Jordan inverse with partial pivoting: Y = A^-1 (column-major).
// Destroys A; col holds n doubles. Returns 0 on a zero or nonfinite pivot column.
__device__ int resident_block_inverse(double* A, double* Y, int n, double* col) {
  __shared__ double s_scale;
  const int tid = threadIdx.x, nt = blockDim.x;
  for (int index = tid; index < n * n; index += nt) Y[index] = index % n == index / n;
  __syncthreads();
  int ok = 1;
  for (int k = 0; k < n; ++k) {
    const int p = resident_block_argmax(A + (size_t)k * n, k, n);
    if (p < 0) {
      ok = 0;
      break;
    }
    if (p != k) {
      for (int c = tid; c < n; c += nt) {
        double x = A[k + (size_t)c * n];
        A[k + (size_t)c * n] = A[p + (size_t)c * n];
        A[p + (size_t)c * n] = x;
        x = Y[k + (size_t)c * n];
        Y[k + (size_t)c * n] = Y[p + (size_t)c * n];
        Y[p + (size_t)c * n] = x;
      }
      __syncthreads();
    }
    if (tid == 0) s_scale = 1.0 / A[k + (size_t)k * n];
    __syncthreads();
    const double scale = s_scale;
    for (int c = tid; c < n; c += nt) {
      A[k + (size_t)c * n] *= scale;
      Y[k + (size_t)c * n] *= scale;
    }
    __syncthreads();
    for (int r = tid; r < n; r += nt) col[r] = A[r + (size_t)k * n];
    __syncthreads();
    for (int index = tid; index < n * n; index += nt) {
      const int r = index % n, c = index / n;
      if (r == k) continue;
      const double x = col[r];
      if (c >= k) A[index] -= x * A[k + (size_t)c * n];
      Y[index] -= x * Y[k + (size_t)c * n];
    }
    __syncthreads();
  }
  return ok;
}

// Publish Y = A^-1 as the mVMC inverse invM = -A^-1 (the interval_resident_commit
// sign), mirroring one rounded skew pair as Julia does after its Gauss-Jordan
// rebuild (cuda_sampling_update.jl:38-60). Returns 0 for a nonfinite entry.
__device__ int resident_publish_inverse(double* inv, const double* Y, int n) {
  __shared__ int s_bad;
  if (threadIdx.x == 0) s_bad = 0;
  __syncthreads();
  for (int index = threadIdx.x; index < n * n; index += blockDim.x) {
    const int r = index % n, c = index / n;
    const double x = r == c ? 0.0 : 0.5 * (Y[r + (size_t)c * n] - Y[c + (size_t)r * n]);
    if (!isfinite(x)) s_bad = 1;
    inv[index] = -x;
  }
  __syncthreads();
  const int ok = !s_bad;
  __syncthreads();
  return ok;
}

// Refactor every plane of one walker on its current sites. Valid planes get
// a published inverse; an invalid plane (zero/nonfinite Pfaffian or a zero
// Gauss-Jordan pivot) keeps its Pfaffian and stale inverse storage, which no
// all-valid path reads. Returns whether every plane is valid.
__device__ int resident_refactor_walker(double* inv, double* pf, int* valid, const int* rs,
                                        const double* slater, int n, int nqp, int n2,
                                        double* fac, double* work, double* vec) {
  __shared__ int s_all;
  if (threadIdx.x == 0) s_all = 1;
  for (int q = 0; q < nqp; ++q) {
    resident_gather(fac, rs, n, -1, -1, slater, q, n2);
    const double p = resident_block_pfaffian(fac, n, vec, vec + n);
    int ok = isfinite(p) && p != 0.0;
    if (ok) {
      resident_gather(fac, rs, n, -1, -1, slater, q, n2);
      ok = resident_block_inverse(fac, work, n, vec);
    }
    if (ok) ok = resident_publish_inverse(inv + (size_t)q * n * n, work, n);
    if (threadIdx.x == 0) {
      pf[q] = p;
      valid[q] = ok;
      if (!ok) s_all = 0;
    }
    __syncthreads();
  }
  const int all = s_all;
  __syncthreads();
  return all;
}
#endif

// Doublon-holon correlation factors on resident walkers (#665, #572 milestone 2).
//
// C projection.c MakeProjCnt: a center site r of table x with occupation
// c = n_up(r) + n_down(r) contributes one count only when it is a holon
// (c = 0) or a doublon (c = 2). xm counts the doublons (holon center) or
// holons (doublon center) on its 2 (DH2) or 4 (DH4) neighbor sites, and the
// counter is offset + x + (c/2 + 2*xm) * N. Julia GPU has no DH support; this
// follows the C counters exactly, which are integers.
//
// `dh` holds the DH2 tables [n2][nsite][2], then the DH4 tables
// [n4][nsite][4]. Item k in [0, (n2+n4)*nsite) selects table k / nsite and
// center k % nsite. `base` is the first DH parameter (NGutzwiller+NJastrow).

#ifndef RESIDENT_DH_CUH
#define RESIDENT_DH_CUH

// Projection parameter index of item k, or -1 for a singly occupied center.
// `Occ` returns the occupation (0/1) of (site, spin).
template <class Occ>
__device__ inline int resident_dh_index(const Occ& occ, const int* dh, int n2, int n4,
                                        int nsite, int base, int k) {
  const int x = k / nsite, r = k % nsite;
  const bool four = x >= n2;
  const int width = four ? 4 : 2;
  const int* nb = four ? dh + (size_t)2 * n2 * nsite + ((size_t)(x - n2) * nsite + r) * 4
                       : dh + ((size_t)x * nsite + r) * 2;
  const int c = occ(r, 0) + occ(r, 1);
  if (c == 1) return -1;
  int xm = 0;
  for (int t = 0; t < width; ++t) {
    const int u = occ(nb[t], 0), d = occ(nb[t], 1);
    xm += c == 0 ? u * d : (1 - u) * (1 - d);
  }
  const int bin = c / 2 + 2 * xm;
  return four ? base + 6 * n2 + (x - n2) + bin * n4 : base + x + bin * n2;
}

// Occupation table `[site] up then [site] down`.
struct ResidentOcc {
  const int* o;
  int nsite;
  __device__ int operator()(int r, int s) const { return o[r + s * nsite]; }
};

// Occupation before one accepted-or-proposed hop ri -> rj of spin `spin`,
// read from the table after the hop.
struct ResidentOccBeforeHop {
  const int* o;
  int nsite, ri, rj, spin;
  __device__ int operator()(int r, int s) const {
    if (s == spin) {
      if (r == ri) return 1;
      if (r == rj) return 0;
    }
    return o[r + s * nsite];
  }
};

// Occupation after merged per-site changes (`du`, `dd`) on `count` sites.
struct ResidentOccMoved {
  const int* o;
  int nsite, count;
  const int* sites;
  const int* du;
  const int* dd;
  __device__ int operator()(int r, int s) const {
    int value = o[r + s * nsite];
    for (int i = 0; i < count; ++i)
      if (sites[i] == r) value += s ? dd[i] : du[i];
    return value;
  }
};

// Partial DH log-weight change sum_k P[after(k)] - P[before(k)] over the items
// k = first, first+stride, ... Unchanged items contribute nothing. Callers
// reduce the partial sums in a fixed order.
template <class Before, class After>
__device__ inline double resident_dh_delta(const Before& before, const After& after,
                                           const int* dh, int n2, int n4, int nsite, int base,
                                           const double* params, int first, int stride) {
  double delta = 0.0;
  const int items = (n2 + n4) * nsite;
  for (int k = first; k < items; k += stride) {
    const int a = resident_dh_index(after, dh, n2, n4, nsite, base, k);
    const int b = resident_dh_index(before, dh, n2, n4, nsite, base, k);
    if (a == b) continue;
    if (a >= 0) delta += params[a];
    if (b >= 0) delta -= params[b];
  }
  return delta;
}

#endif

// RBM correlation factors on resident walkers (#667, #572 milestone 3).
//
// Physics: C rbm.c on the complex normal path (vmcmake.c, calham.c, calgrn.c,
// vmccal.c), restricted to real coefficients, where every quantity is real.
// C's real path (vmcmake_real.c, calham_real.c) omits the RBM factor from
// the Metropolis ratio and the local energy, and RBMDiff then reads RBMCnt
// that vmcmake_real.c never saves. The resident path keeps the factor in
// the wave function everywhere, as the complex C path does.
//
// `rbm` tables (built by opt/model.rs; indices relative to the RBM block,
// C RBM = Para + NProj; -1 means absent):
//   [0, ns)            ChargeRBM_PhysLayerIdx[r]
//   [ns, 2ns)          SpinRBM_PhysLayerIdx[r] + NChargeRBM_PhysLayerIdx
//   [2ns, 4ns)         GeneralRBM_PhysLayerIdx[r + s*ns] + NCharge + NSpin
//   [4ns, 4ns+H)       family of neuron h: 0 charge, 1 spin, 2 general
//   [4ns+H, 4ns+2H)    hidden-layer coefficient of neuron h
//   [4ns+2H, ...)      [h][rs] physical-hidden coefficient (charge/spin use
//                      rs < ns, general rs = r + s*ns)
// Neurons are ordered charge, spin, general (C rbmCnt layout). `wt` holds the
// NRBM coefficients and `theta[w*H + h]` the hidden field of walker w.

#ifndef RESIDENT_RBM_CUH
#define RESIDENT_RBM_CUH

__device__ inline int resident_rbm_family(const int* rbm, int ns, int h) {
  return rbm[4 * ns + h];
}

__device__ inline const int* resident_rbm_coupling(const int* rbm, int ns, int H, int h) {
  return rbm + 4 * ns + 2 * H + (size_t)h * 2 * ns;
}

// C MakeRBMCnt for neuron h: theta = 0 + bias, then += sum_r W[r] x_r with
// the coupling sum accumulated separately in site order (rbm.c:216-270).
// x_r = n_up + n_down - 1 (charge), n_up - n_down (spin), 2 n_rs - 1 (general).
__device__ inline double resident_rbm_make(const int* rbm, const double* wt, const int* occ,
                                           int ns, int H, int h) {
  const int family = resident_rbm_family(rbm, ns, h);
  const int b = rbm[4 * ns + H + h];
  const int* c = resident_rbm_coupling(rbm, ns, H, h);
  double theta = 0.0;
  if (b >= 0) theta = __dadd_rn(theta, wt[b]);
  if (c[0] >= 0) {
    double sum = 0.0;
    const int width = family == 2 ? 2 * ns : ns;
    for (int rs = 0; rs < width; ++rs) {
      const int x = family == 0 ? occ[rs] + occ[rs + ns] - 1
                  : family == 1 ? occ[rs] - occ[rs + ns]
                                : 2 * occ[rs] - 1;
      sum = __dadd_rn(sum, __dmul_rn(wt[c[rs]], (double)x));
    }
    theta = __dadd_rn(theta, sum);
  }
  return theta;
}

// C UpdateRBMCnt for neuron h of a hop ri -> rj with spin s (rbm.c:426-461):
// subtract the source coupling, then add the destination coupling, scaled by
// 1 (charge), 1-2s (spin) or 2 (general, at r + s*ns).
__device__ inline double resident_rbm_hop(const int* rbm, const double* wt, int ns, int H, int h,
                                          double theta, int ri, int rj, int s) {
  if (ri == rj) return theta;
  const int family = resident_rbm_family(rbm, ns, h);
  const int* c = resident_rbm_coupling(rbm, ns, H, h);
  if (c[0] < 0) return theta;
  if (family == 2) {
    theta = __dsub_rn(theta, __dmul_rn(2.0, wt[c[ri + s * ns]]));
    return __dadd_rn(theta, __dmul_rn(2.0, wt[c[rj + s * ns]]));
  }
  const double k = family == 1 ? (double)(1 - 2 * s) : 1.0;
  theta = __dsub_rn(theta, __dmul_rn(k, wt[c[ri]]));
  return __dadd_rn(theta, __dmul_rn(k, wt[c[rj]]));
}

// Real part of C LogRBMRatio's per-neuron terms (rbm.c:139-160) for real
// fields: fold to |theta|, add |new| - |old| and log((1+e^{-2|new|}) /
// (1+e^{-2|old|})). C multiplies the ratios of a block before one log; the
// resident path takes the log per neuron so neurons can be reduced in
// parallel (log of a product of positive factors, rounding only).
__device__ inline double resident_rbm_log_cosh_ratio(double tnew, double told) {
  const double a = fabs(tnew), b = fabs(told);
  const double factor = (1.0 + exp(-2.0 * a)) / (1.0 + exp(-2.0 * b));
  return __dadd_rn(__dsub_rn(a, b), log(factor));
}

// Physical-layer part of LogRBMRatio, sum_idx RBM[idx] (new - old), for up to
// two hops (ri[k] -> rj[k], spin s[k]). Counter changes follow UpdateRBMCnt;
// coinciding counters are merged and summed in ascending index order, as C
// sums over every idx (the unchanged ones contribute +-0).
__device__ inline double resident_rbm_phys_delta(const int* rbm, const double* wt, int ns,
                                                 const int* ri, const int* rj, const int* s,
                                                 int hops) {
  int idx[12];
  int d[12];
  int count = 0;
  auto add = [&](int i, int v) {
    if (i < 0) return;
    for (int k = 0; k < count; ++k)
      if (idx[k] == i) {
        d[k] += v;
        return;
      }
    idx[count] = i;
    d[count] = v;
    ++count;
  };
  for (int k = 0; k < hops; ++k) {
    if (ri[k] == rj[k]) continue;
    add(rbm[ri[k]], -1);
    add(rbm[rj[k]], 1);
    add(rbm[ns + ri[k]], 2 * s[k] - 1);
    add(rbm[ns + rj[k]], 1 - 2 * s[k]);
    add(rbm[2 * ns + ri[k] + s[k] * ns], -2);
    add(rbm[2 * ns + rj[k] + s[k] * ns], 2);
  }
  double z = 0.0;
  int last = -1;
  for (int n = 0; n < count; ++n) {
    int best = -1;
    for (int k = 0; k < count; ++k)
      if (idx[k] > last && (best < 0 || idx[k] < idx[best])) best = k;
    last = idx[best];
    if (d[best] != 0) z = __dadd_rn(z, __dmul_rn(wt[idx[best]], (double)d[best]));
  }
  return z;
}

// Hidden-layer part of LogRBMRatio for up to two hops, over the neurons
// h = first, first+stride, ... Callers reduce the partial sums in a fixed order.
__device__ inline double resident_rbm_hidden_delta(const int* rbm, const double* wt,
                                                   const double* theta_w, int ns, int H,
                                                   const int* ri, const int* rj, const int* s,
                                                   int hops, int first, int stride) {
  double z = 0.0;
  for (int h = first; h < H; h += stride) {
    const double told = theta_w[h];
    double tnew = told;
    for (int k = 0; k < hops; ++k) tnew = resident_rbm_hop(rbm, wt, ns, H, h, tnew, ri[k], rj[k], s[k]);
    z += resident_rbm_log_cosh_ratio(tnew, told);
  }
  return z;
}

#endif

// Complex FP64 helpers of the resident complex normal-orbital path (#678).
//
// `rcx` is an interleaved (re, im) pair, the layout of `Cx<double>` in
// pfaffian_batched.cu and of num_complex::Complex64 on the host. Every
// product and sum is separately rounded (no FMA contraction), so a result
// depends only on the operation order written here. Division follows Smith's
// algorithm, as `Cx` does.
//
// The block helpers mirror resident_dense.cuh (#573) with complex arithmetic:
// gather, PFAPACK pfaffian_LTL with partial pivoting (pivot magnitude
// |re|+|im|, the izamax norm), Gauss-Jordan inverse, skew publication and the
// per-walker refactor. Matrices are column-major, A(r,c) = A[r + c*n].
#ifndef MVMC_RESIDENT_COMPLEX
#define MVMC_RESIDENT_COMPLEX
#ifndef SLT
#define SLT(tab, qp, row, col, n2) ((tab)[(((size_t)(qp) * (n2)) + (row)) * (n2) + (col)])
#endif

struct rcx {
  double re, im;
};

__device__ __forceinline__ rcx rc(double re, double im) {
  rcx z;
  z.re = re;
  z.im = im;
  return z;
}
__device__ __forceinline__ rcx rc_add(rcx a, rcx b) {
  return rc(__dadd_rn(a.re, b.re), __dadd_rn(a.im, b.im));
}
__device__ __forceinline__ rcx rc_sub(rcx a, rcx b) {
  return rc(__dsub_rn(a.re, b.re), __dsub_rn(a.im, b.im));
}
__device__ __forceinline__ rcx rc_neg(rcx a) { return rc(-a.re, -a.im); }
__device__ __forceinline__ rcx rc_conj(rcx a) { return rc(a.re, -a.im); }
__device__ __forceinline__ rcx rc_mul(rcx a, rcx b) {
  return rc(__dsub_rn(__dmul_rn(a.re, b.re), __dmul_rn(a.im, b.im)),
            __dadd_rn(__dmul_rn(a.re, b.im), __dmul_rn(a.im, b.re)));
}
__device__ __forceinline__ rcx rc_scale(rcx a, double s) {
  return rc(__dmul_rn(a.re, s), __dmul_rn(a.im, s));
}
__device__ inline rcx rc_div(rcx a, rcx b) {
  if (fabs(b.re) >= fabs(b.im)) {
    const double r = __ddiv_rn(b.im, b.re), d = __dadd_rn(b.re, __dmul_rn(b.im, r));
    return rc(__ddiv_rn(__dadd_rn(a.re, __dmul_rn(a.im, r)), d),
              __ddiv_rn(__dsub_rn(a.im, __dmul_rn(a.re, r)), d));
  }
  const double r = __ddiv_rn(b.re, b.im), d = __dadd_rn(__dmul_rn(b.re, r), b.im);
  return rc(__ddiv_rn(__dadd_rn(__dmul_rn(a.re, r), a.im), d),
            __ddiv_rn(__dsub_rn(__dmul_rn(a.im, r), a.re), d));
}
__device__ __forceinline__ double rc_abs1(rcx a) { return fabs(a.re) + fabs(a.im); }
__device__ __forceinline__ double rc_abs(rcx a) { return hypot(a.re, a.im); }
__device__ __forceinline__ bool rc_finite(rcx a) { return isfinite(a.re) && isfinite(a.im); }
__device__ __forceinline__ bool rc_zero(rcx a) { return a.re == 0.0 && a.im == 0.0; }

// Fixed-order warp reduction of both components; every lane receives the sum.
__device__ inline rcx rc_warp_sum(rcx x) {
  for (int d = 16; d; d >>= 1) {
    x.re += __shfl_down_sync(0xffffffff, x.re, d);
    x.im += __shfl_down_sync(0xffffffff, x.im, d);
  }
  return rc(__shfl_sync(0xffffffff, x.re, 0), __shfl_sync(0xffffffff, x.im, 0));
}

// Gather the skew plane of global sites rs[0..n), omitting electron slots
// `skip_a` and `skip_b` (pass -1 to keep all). Returns the gathered side.
__device__ inline int rc_gather(rcx* A, const int* rs, int n, int skip_a, int skip_b,
                                const rcx* slater, int q, int n2) {
  const int m = n - (skip_a >= 0) - (skip_b >= 0);
  for (int index = threadIdx.x; index < m * m; index += blockDim.x) {
    int r = index % m, c = index / m;
    r += (skip_a >= 0 && r >= skip_a);
    r += (skip_b >= 0 && r >= skip_b);
    c += (skip_a >= 0 && c >= skip_a);
    c += (skip_b >= 0 && c >= skip_b);
    A[index] = rc_neg(SLT(slater, q, rs[c], rs[r], n2));
  }
  __syncthreads();
  return m;
}

// First index of the largest |re|+|im| over begin <= i < end (ties keep the
// smallest index). Returns -1 when every entry is zero and -2 when any entry
// is nonfinite.
__device__ int rc_block_argmax(const rcx* x, int begin, int end) {
  __shared__ double s_value[32];
  __shared__ int s_index[32];
  const int tid = threadIdx.x, lane = tid & 31, warp = tid >> 5;
  const int warps = blockDim.x >> 5;
  double best = -1.0;
  int index = end, nonfinite = 0;
  for (int i = begin + tid; i < end; i += blockDim.x) {
    const double v = rc_abs1(x[i]);
    nonfinite |= !isfinite(v);
    if (v > best) {
      best = v;
      index = i;
    }
  }
  for (int d = 16; d; d >>= 1) {
    const double other = __shfl_down_sync(0xffffffff, best, d);
    const int at = __shfl_down_sync(0xffffffff, index, d);
    if (other > best || (other == best && at < index)) {
      best = other;
      index = at;
    }
  }
  if (lane == 0) {
    s_value[warp] = best;
    s_index[warp] = index;
  }
  nonfinite = __syncthreads_or(nonfinite);
  if (warp == 0) {
    best = lane < warps ? s_value[lane] : -1.0;
    index = lane < warps ? s_index[lane] : end;
    for (int d = 16; d; d >>= 1) {
      const double other = __shfl_down_sync(0xffffffff, best, d);
      const int at = __shfl_down_sync(0xffffffff, index, d);
      if (other > best || (other == best && at < index)) {
        best = other;
        index = at;
      }
    }
    if (lane == 0) s_index[0] = nonfinite ? -2 : (best > 0.0 ? index : -1);
  }
  __syncthreads();
  const int result = s_index[0];
  __syncthreads();
  return result;
}

// Complex Pfaffian by skew Parlett-Reid elimination with partial pivoting,
// resident_block_pfaffian with complex arithmetic. An exactly zero pivot
// column gives Pf = 0; a nonfinite column gives NaN. Destroys A; tau and u
// hold n values each. Every thread of the block receives the same value.
__device__ rcx rc_block_pfaffian_unblocked(rcx* A, int n, rcx* tau, rcx* u) {
  __shared__ rcx s_pf;
  const int tid = threadIdx.x, nt = blockDim.x;
  if (tid == 0) s_pf = rc(1.0, 0.0);
  __syncthreads();
  for (int k = 0; k + 1 < n; k += 2) {
    const int kp = rc_block_argmax(A + (size_t)k * n, k + 1, n);
    if (kp < 0) {
      if (tid == 0) {
        const double nan = __longlong_as_double(0x7ff8000000000000LL);
        s_pf = kp == -1 ? rc(0.0, 0.0) : rc(nan, nan);
      }
      __syncthreads();
      break;
    }
    if (kp != k + 1) {
      for (int c = tid; c < n; c += nt) {
        const rcx x = A[(k + 1) + (size_t)c * n];
        A[(k + 1) + (size_t)c * n] = A[kp + (size_t)c * n];
        A[kp + (size_t)c * n] = x;
      }
      __syncthreads();
      for (int r = tid; r < n; r += nt) {
        const rcx x = A[r + (size_t)(k + 1) * n];
        A[r + (size_t)(k + 1) * n] = A[r + (size_t)kp * n];
        A[r + (size_t)kp * n] = x;
      }
      if (tid == 0) s_pf = rc_neg(s_pf);
      __syncthreads();
    }
    const rcx pivot = A[k + (size_t)(k + 1) * n];
    if (tid == 0) s_pf = rc_mul(s_pf, pivot);
    for (int c = k + 2 + tid; c < n; c += nt) {
      tau[c] = rc_div(A[k + (size_t)c * n], pivot);
      u[c] = A[c + (size_t)(k + 1) * n];
    }
    __syncthreads();
    const int width = n - k - 2;
    for (int index = tid; index < width * width; index += nt) {
      const int r = k + 2 + index % width, c = k + 2 + index / width;
      const rcx delta = rc_sub(rc_mul(tau[r], u[c]), rc_mul(u[r], tau[c]));
      A[r + (size_t)c * n] = rc_add(A[r + (size_t)c * n], delta);
    }
    __syncthreads();
  }
  const rcx result = s_pf;
  __syncthreads();
  return result;
}

struct ResidentComplexPfOps {
  typedef rcx T;
  __device__ static T one() { return rc(1.0, 0.0); }
  __device__ static T zero() { return rc(0.0, 0.0); }
  __device__ static T nan() { const double x = __longlong_as_double(0x7ff8000000000000LL); return rc(x,x); }
  __device__ static T neg(T x) { return rc_neg(x); }
  __device__ static T add(T x, T y) { return rc_add(x,y); }
  __device__ static T sub(T x, T y) { return rc_sub(x,y); }
  __device__ static T mul(T x, T y) { return rc_mul(x,y); }
  __device__ static T div(T x, T y) { return rc_div(x,y); }
  __device__ static int argmax(const T* x, int begin, int end) {
    return rc_block_argmax(x, begin, end);
  }
};

__device__ rcx rc_block_pfaffian(rcx* A, int n, rcx* tau, rcx* u) {
  if (n < 64) return rc_block_pfaffian_unblocked(A, n, tau, u);
  return resident_panel_pfaffian<ResidentComplexPfOps>(A, n, tau, u);
}

// Gauss-Jordan inverse with partial pivoting: Y = A^-1 (column-major).
// Destroys A; col holds n values. Returns 0 on a zero or nonfinite pivot column.
__device__ int rc_block_inverse(rcx* A, rcx* Y, int n, rcx* col) {
  __shared__ rcx s_scale;
  const int tid = threadIdx.x, nt = blockDim.x;
  for (int index = tid; index < n * n; index += nt)
    Y[index] = rc(index % n == index / n ? 1.0 : 0.0, 0.0);
  __syncthreads();
  int ok = 1;
  for (int k = 0; k < n; ++k) {
    const int p = rc_block_argmax(A + (size_t)k * n, k, n);
    if (p < 0) {
      ok = 0;
      break;
    }
    if (p != k) {
      for (int c = tid; c < n; c += nt) {
        rcx x = A[k + (size_t)c * n];
        A[k + (size_t)c * n] = A[p + (size_t)c * n];
        A[p + (size_t)c * n] = x;
        x = Y[k + (size_t)c * n];
        Y[k + (size_t)c * n] = Y[p + (size_t)c * n];
        Y[p + (size_t)c * n] = x;
      }
      __syncthreads();
    }
    if (tid == 0) s_scale = rc_div(rc(1.0, 0.0), A[k + (size_t)k * n]);
    __syncthreads();
    const rcx scale = s_scale;
    for (int c = tid; c < n; c += nt) {
      A[k + (size_t)c * n] = rc_mul(A[k + (size_t)c * n], scale);
      Y[k + (size_t)c * n] = rc_mul(Y[k + (size_t)c * n], scale);
    }
    __syncthreads();
    for (int r = tid; r < n; r += nt) col[r] = A[r + (size_t)k * n];
    __syncthreads();
    for (int index = tid; index < n * n; index += nt) {
      const int r = index % n, c = index / n;
      if (r == k) continue;
      const rcx x = col[r];
      if (c >= k) A[index] = rc_sub(A[index], rc_mul(x, A[k + (size_t)c * n]));
      Y[index] = rc_sub(Y[index], rc_mul(x, Y[k + (size_t)c * n]));
    }
    __syncthreads();
  }
  return ok;
}

// Publish Y = A^-1 as the mVMC inverse invM = -A^-1, mirroring one rounded
// skew pair (resident_publish_inverse). Returns 0 for a nonfinite entry.
__device__ int rc_publish_inverse(rcx* inv, const rcx* Y, int n) {
  __shared__ int s_bad;
  if (threadIdx.x == 0) s_bad = 0;
  __syncthreads();
  for (int index = threadIdx.x; index < n * n; index += blockDim.x) {
    const int r = index % n, c = index / n;
    const rcx x = r == c ? rc(0.0, 0.0)
                         : rc_scale(rc_sub(Y[r + (size_t)c * n], Y[c + (size_t)r * n]), 0.5);
    if (!rc_finite(x)) s_bad = 1;
    inv[index] = rc_neg(x);
  }
  __syncthreads();
  const int ok = !s_bad;
  __syncthreads();
  return ok;
}

// Refactor every plane of one walker on its current sites
// (resident_refactor_walker). Returns whether every plane is valid.
__device__ int rc_refactor_walker(rcx* inv, rcx* pf, int* valid, const int* rs, const rcx* slater,
                                  int n, int nqp, int n2, rcx* fac, rcx* work, rcx* vec) {
  __shared__ int s_all;
  if (threadIdx.x == 0) s_all = 1;
  for (int q = 0; q < nqp; ++q) {
    rc_gather(fac, rs, n, -1, -1, slater, q, n2);
    const rcx p = rc_block_pfaffian(fac, n, vec, vec + n);
    int ok = rc_finite(p) && !rc_zero(p);
    if (ok) {
      rc_gather(fac, rs, n, -1, -1, slater, q, n2);
      ok = rc_block_inverse(fac, work, n, vec);
    }
    if (ok) ok = rc_publish_inverse(inv + (size_t)q * n * n, work, n);
    if (threadIdx.x == 0) {
      pf[q] = p;
      valid[q] = ok;
      if (!ok) s_all = 0;
    }
    __syncthreads();
  }
  const int all = s_all;
  __syncthreads();
  return all;
}
#endif

// Shared paired factorization for the complete Pfaffian/inverse rebuild.
// Exactly the existing A/W/OUT matrices are used; no extra device allocation.
// Real n=64..126 and complex n>=64 select this path. The existing Julia
// paired real n>=128 path is faster and keeps its independent C fallback.
#ifndef MVMC_PFAFFIAN_INVERSE_PANEL
#define MVMC_PFAFFIAN_INVERSE_PANEL
struct PfinvRealPanelOps : ResidentRealPfOps {
  __device__ static bool finite(T x) { return isfinite(x); }
  __device__ static void reference(T*,T*,T*,T*,int*,int);
};
struct PfinvComplexPanelOps : ResidentComplexPfOps {
  __device__ static bool finite(T x) { return rc_finite(x); }
  __device__ static void reference(T*,T*,T*,T*,int*,int);
};

template <typename Ops>
__device__ void pfinv_panel_plane(typename Ops::T* A, typename Ops::T* W,
    typename Ops::T* OUT, typename Ops::T* PF, int* ST, int n) {
  typedef typename Ops::T T;
  extern __shared__ char panel_mem[];
  T* tau=reinterpret_cast<T*>(panel_mem);
  T* u=tau+n;
  T* diagonal=u+n;
  int* permutation=reinterpret_cast<int*>(diagonal+n/2);
  __shared__ int status;
  const int tid=threadIdx.x, nt=blockDim.x;
  const size_t nn=(size_t)n*n;
  // Preserve input for the exact reference failure/status path.
  for (size_t i=tid;i<nn;i+=nt) W[i]=A[i];
  __syncthreads();
  const T pf=resident_panel_pfaffian<Ops,true>(A,n,tau,u,OUT,diagonal,permutation,&status);
  if (status!=0) {
    for (size_t i=tid;i<nn;i+=nt) A[i]=W[i];
    __syncthreads();
    Ops::reference(A,W,OUT,PF,ST,n);
    return;
  }
  if (!Ops::finite(pf)) {
    for (size_t i=tid;i<nn;i+=nt) A[i]=W[i];
    __syncthreads();
    Ops::reference(A,W,OUT,PF,ST,n);
    return;
  }
  int bad_reciprocal=0;
  for (int i=tid;i<n/2;i+=nt) {
    diagonal[i]=Ops::div(Ops::one(),diagonal[i]);
    bad_reciprocal |= !Ops::finite(diagonal[i]);
  }
  // Removing products with structural zeros is valid for finite L. Preserve
  // the reference fallback when a factor is nonfinite: the old full dot
  // would encounter nonfinite*0 on its diagonal even if pf stayed finite.
  for (size_t i=tid;i<nn;i+=nt) bad_reciprocal |= !Ops::finite(OUT[i]);
  bad_reciprocal=__syncthreads_or(bad_reciprocal);
  if (bad_reciprocal) {
    for (size_t i=tid;i<nn;i+=nt) A[i]=W[i];
    __syncthreads();
    Ops::reference(A,W,OUT,PF,ST,n);
    return;
  }
  // Reuse A for B=L^-1, row-major for coalesced accesses across columns.
  // Keep W's exact original input through inversion, not just factorization:
  // a finite inverse can have nonrepresentable intermediate lower factors.
  for (size_t i=tid;i<nn;i+=nt) A[i]=Ops::zero();
  __syncthreads();
  for (int row=0;row<n;++row) {
    for (int col=tid;col<=row;col+=nt) {
      T value=row==col ? Ops::one() : Ops::zero();
      // B[k,col] is the untouched structural zero for k<col. The remaining
      // terms retain their original order, including diagonal publication.
      for (int k=col;k<row;++k)
        value=Ops::sub(value,Ops::mul(OUT[row+(size_t)k*n],A[col+(size_t)k*n]));
      A[col+(size_t)row*n]=value;
    }
    __syncthreads();
  }
  // B^T D^-1 B: only one triangle is evaluated. Pair products avoid
  // materializing D^-1 B and reuse the diagonal in shared memory.
  int bad=0;
  for (int j=tid;j<n;j+=nt) OUT[permutation[j]+(size_t)permutation[j]*n]=Ops::zero();
  for (size_t index=tid;index<nn;index+=nt) {
    const int row=index%n, col=index/n;
    if (row<=col) continue;
    T value=Ops::zero();
    for (int k=row & ~1;k<n;k+=2) {
      const T delta=Ops::sub(Ops::mul(A[row+(size_t)k*n],A[col+(size_t)(k+1)*n]),
                            Ops::mul(A[row+(size_t)(k+1)*n],A[col+(size_t)k*n]));
      value=Ops::add(value,Ops::mul(delta,diagonal[k/2]));
    }
    bad |= !Ops::finite(value);
    OUT[permutation[row]+(size_t)permutation[col]*n]=value;
    OUT[permutation[col]+(size_t)permutation[row]*n]=Ops::neg(value);
  }
  bad=__syncthreads_or(bad);
  if (bad) {
    for (size_t i=tid;i<nn;i+=nt) A[i]=W[i];
    __syncthreads();
    Ops::reference(A,W,OUT,PF,ST,n);
    return;
  }
  if (tid==0) { *PF=pf; *ST=0; }
}
#endif

// Batched Pfaffian + inverse of skew-symmetric matrices, one thread block per plane.
//
// The reference path follows crates/pfapack: dsktf2/zsktf2 (skew LTL^T with partial
// pivoting, upper storage), utu2pfa, utu2inv. Planes are column-major n x n, stored back to
// back (plane p at offset p*n*n). The kernel works in global memory (the planes of n = 2*Ne up
// to 128 do not fit shared memory for complex data) with small per-plane vectors in dynamic
// shared memory. Compile with --fmad=false so the rank-2 update keeps pfapack's operation
// order, (c + x t1) - y t2.
//
// Status codes (int per plane): 0 ok, k > 0 zero pivot (pfapack INFO, 1-based row),
// -1 non-finite Pfaffian. For status != 0 the output plane is zero; a zero-pivot plane
// reports pf = 0.
// Production also selects a shared paired panel factorization for real
// n=64..126 and complex n>=64. Large real resident rebuilds retain their
// faster Julia paired kernel and this file's independent cancellation fallback.

template <typename R> struct Cx { R re, im; };

template <typename R> __device__ inline Cx<R> operator+(Cx<R> a, Cx<R> b) { return {a.re + b.re, a.im + b.im}; }
template <typename R> __device__ inline Cx<R> operator-(Cx<R> a, Cx<R> b) { return {a.re - b.re, a.im - b.im}; }
template <typename R> __device__ inline Cx<R> operator-(Cx<R> a) { return {-a.re, -a.im}; }
template <typename R> __device__ inline Cx<R> operator*(Cx<R> a, Cx<R> b) {
  return {a.re * b.re - a.im * b.im, a.re * b.im + a.im * b.re};
}
// Smith's algorithm.
template <typename R> __device__ inline Cx<R> operator/(Cx<R> a, Cx<R> b) {
  if (fabs(b.re) >= fabs(b.im)) {
    R r = b.im / b.re, d = b.re + b.im * r;
    return {(a.re + a.im * r) / d, (a.im - a.re * r) / d};
  } else {
    R r = b.re / b.im, d = b.re * r + b.im;
    return {(a.re * r + a.im) / d, (a.im * r - a.re) / d};
  }
}

template <typename T> struct Tr {  // real scalar
  typedef T R;
  __device__ static T make(R re, R) { return re; }
  __device__ static R mag(T x) { return fabs(x); }
  __device__ static bool finite(T x) { return x - x == R(0); }
};
template <typename Rr> struct Tr<Cx<Rr>> {  // complex scalar
  typedef Rr R;
  __device__ static Cx<Rr> make(R re, R im) { return {re, im}; }
  __device__ static R mag(Cx<Rr> x) { return fabs(x.re) + fabs(x.im); }  // izamax norm
  __device__ static bool finite(Cx<Rr> x) { return (x.re - x.re == Rr(0)) && (x.im - x.im == Rr(0)); }
};

template <typename T>
__device__ void pfinv_plane(T* A, T* W, T* OUT, T* PF, int* ST, int n) {
  typedef Tr<T> TR;
  typedef typename TR::R R;
  extern __shared__ char smem_raw[];
  T* vt = reinterpret_cast<T*>(smem_raw);                 // n
  R* red_v = reinterpret_cast<R*>(vt + n);                // blockDim
  int* red_i = reinterpret_cast<int*>(red_v + blockDim.x);  // blockDim
  int* idx = red_i + blockDim.x;                          // n
  int* piv = idx + n;                                     // n
  __shared__ int s_kp, s_info, s_zero, s_status;
  __shared__ R s_colmax;

  const int tid = threadIdx.x, nt = blockDim.x;
  const T one = TR::make(R(1), R(0));
  const T zero = TR::make(R(0), R(0));
  const size_t nn = (size_t)n * n;
  for (int i = tid; i < n; i += nt) piv[i] = i;
  if (tid == 0) s_info = 0;
  __syncthreads();

  // ---- Phase 1: LTL^T factorization, k0 = n-1 .. 1 (0-based), kk = k0-1 -------------------
  for (int k0 = n - 1; k0 >= 1; --k0) {
    const int kk = k0 - 1;
    // First-index argmax of mag(A[0..kk, k0]); NaN loses except at index 0 (as the scalar
    // `v > colmax` scan does).
    R bv = R(-1);
    int bi = 0x7fffffff;
    for (int j = tid; j <= kk; j += nt) {
      R v = TR::mag(A[j + (size_t)k0 * n]);
      if (v != v) v = (j == 0) ? R(1e300) * R(1e300) : R(-1);
      if (v > bv || (v == bv && j < bi)) { bv = v; bi = j; }
    }
    red_v[tid] = bv;
    red_i[tid] = bi;
    __syncthreads();
    for (int s = nt >> 1; s > 0; s >>= 1) {
      if (tid < s) {
        R ov = red_v[tid + s];
        int oi = red_i[tid + s];
        if (ov > red_v[tid] || (ov == red_v[tid] && oi < red_i[tid])) { red_v[tid] = ov; red_i[tid] = oi; }
      }
      __syncthreads();
    }
    if (tid == 0) {
      int kp = red_i[0];
      if (kp > kk) kp = kk;
      s_kp = kp;
      s_colmax = TR::mag(A[kp + (size_t)k0 * n]);
      s_zero = (s_colmax == R(0)) ? 1 : 0;
      if (s_zero) {
        if (s_info == 0) s_info = kk + 1;
      } else {
        piv[kk] = kp;
      }
    }
    __syncthreads();
    if (s_zero) continue;
    const int kp = s_kp;

    if (kp != kk) {
      for (int j = tid; j < kp; j += nt) {
        T t = A[j + (size_t)kk * n]; A[j + (size_t)kk * n] = A[j + (size_t)kp * n]; A[j + (size_t)kp * n] = t;
      }
      for (int j = kp + 1 + tid; j < kk; j += nt) {
        T t = A[j + (size_t)kk * n]; A[j + (size_t)kk * n] = A[kp + (size_t)j * n]; A[kp + (size_t)j * n] = t;
      }
      for (int j = k0 + tid; j < n; j += nt) {
        T t = A[kk + (size_t)j * n]; A[kk + (size_t)j * n] = A[kp + (size_t)j * n]; A[kp + (size_t)j * n] = t;
      }
      __syncthreads();
      for (int j = kp + tid; j < kk; j += nt) A[j + (size_t)kk * n] = -A[j + (size_t)kk * n];
      for (int j = kp + 1 + tid; j < kk; j += nt) A[kp + (size_t)j * n] = -A[kp + (size_t)j * n];
      __syncthreads();
    }

    if (kk >= 1) {
      const T alpha = one / A[kk + (size_t)k0 * n];
      // Upper rank-2 update of A[0..kk, 0..kk]: A_ij = (A_ij + x_i t1_j) - y_i t2_j, i < j,
      // x = A[:, k0], y = A[:, kk], t1 = alpha y_j, t2 = alpha x_j; the diagonal is set to 0.
      for (int e = tid; e < kk * kk; e += nt) {
        const int i = e % kk, j = e / kk;
        if (i > j) continue;
        if (i == j) { A[j + (size_t)j * n] = zero; continue; }
        const T x = A[i + (size_t)k0 * n], y = A[i + (size_t)kk * n];
        const T t1 = alpha * A[j + (size_t)kk * n];
        const T t2 = alpha * A[j + (size_t)k0 * n];
        A[i + (size_t)j * n] = (A[i + (size_t)j * n] + x * t1) - y * t2;
      }
      __syncthreads();
      for (int i = tid; i < kk; i += nt) A[i + (size_t)k0 * n] = A[i + (size_t)k0 * n] * alpha;
      __syncthreads();
    }
  }
  __syncthreads();

  // ---- Phase 2: Pfaffian and status -------------------------------------------------------
  if (tid == 0) {
    int status = 0;
    T pf = zero;
    if (s_info > 0) {
      status = s_info;
    } else {
      pf = one;
      for (int i = 0; i + 1 < n; i += 2) pf = pf * A[i + (size_t)(i + 1) * n];
      int flips = 0;
      for (int k = 0; k < n; ++k) flips += (piv[k] != k);
      if (flips & 1) pf = zero - pf;
      if (!TR::finite(pf)) status = -1;
    }
    s_status = status;
    PF[0] = pf;
    ST[0] = status;
  }
  __syncthreads();
  if (s_status != 0) {
    for (size_t e = tid; e < nn; e += nt) OUT[e] = zero;
    return;
  }

  // ---- Phase 3: inverse (utu2inv) ----------------------------------------------------------
  // M = I-like workspace: columns 0..n-2 hold X = S^-1 (S[i,k] = A[i,k+1], unit upper), the last
  // column is e_{n-1}. One thread per column (back substitution).
  for (size_t e = tid; e < nn; e += nt) W[e] = zero;
  __syncthreads();
  for (int c = tid; c < n - 1; c += nt) {
    T* xc = W + (size_t)c * n;
    xc[c] = one;
    for (int i = c - 1; i >= 0; --i) {
      T acc = zero;
      for (int k = i + 1; k <= c; ++k) acc = acc + A[i + (size_t)(k + 1) * n] * xc[k];
      xc[i] = zero - acc;
    }
  }
  if (tid == 0) W[(n - 1) + (size_t)(n - 1) * n] = one;
  for (int i = tid; i < n - 1; i += nt) vt[i] = -A[i + (size_t)(i + 1) * n];
  __syncthreads();
  // Skew-tridiagonal solve C = T^-1 M per column (C overwrites A).
  for (int j = tid; j < n; j += nt) {
    const T* b = W + (size_t)j * n;
    T* c = A + (size_t)j * n;
    c[1] = b[0] / (-vt[0]);
    for (int i = 2; i < n; i += 2) c[i + 1] = (b[i] - c[i - 1] * vt[i - 1]) / (-vt[i]);
    c[n - 2] = b[n - 1] / vt[n - 2];
    for (int i = n - 3; i >= 1; i -= 2) c[i - 1] = (b[i] + c[i + 1] * vt[i]) / vt[i - 1];
  }
  // Composed pivot permutation (swap sequence j = 0..n-1).
  if (tid == 0) {
    for (int i = 0; i < n; ++i) idx[i] = i;
    for (int j = 0; j < n; ++j) { int t = piv[j], a = idx[j]; idx[j] = idx[t]; idx[t] = a; }
  }
  __syncthreads();
  // Out[r,c] = sum_{k <= idx[r]} M[k, idx[r]] * C[k, idx[c]].
  for (int e = tid; e < n * n; e += nt) {
    const int r = e % n, c = e / n;
    const int ir = idx[r], ic = idx[c];
    T acc = zero;
    for (int k = 0; k <= ir; ++k) acc = acc + W[k + (size_t)ir * n] * A[k + (size_t)ic * n];
    OUT[r + (size_t)c * n] = acc;
  }
}


// ---------------------------------------------------------------------------------------------
// Fast path for real double matrices, n >= 64 and even (issue #517).
//
// The generic `pfinv_plane<T>` above still serves the f32/c64 variants and the small real
// batches unchanged; this path is used only by `pfinv_f64`, i.e. the production kernel of the
// device-sampler recompute and the measurement side. Every per-element formula is unchanged,
// so the two paths agree bit for bit through the whole factorization and the Pfaffian and
// differ by rounding only in the mirrored half of the inverse (see phase 3(d)). Phase 3(b) is
// left in the exact C operation order on purpose: splitting each dot product into partial sums
// was measured and gave no gain (the phase is memory-bound), so it is not kept.
//
//  * phase 1 stages x = A[:, k0], y = A[:, kk], t1 = alpha*y and t2 = alpha*x in shared memory
//    once per step (4n doubles), scales column k0 in the same pass, and then applies the
//    strict-upper rank-2 update A_ij = (A_ij + x_i t1_j) - y_i t2_j with one double2 load and
//    one double2 store per two elements, with warp-cyclic columns. The generic path re-reads
//    five global values per element and computes every index with % and /; the pivot search
//    here reduces with __shfl_down_sync plus one shared-memory round instead of log2(nt)
//    __syncthreads. Sweeping whole columns per warp amortizes the t1s/t2s reads over 64 rows.
//  * phase 3(d) computes M^T C as a register-tiled GEMM restricted to the upper triangle of
//    the pre-permutation index space and writes the transposed entry as its exact negative:
//    for n a multiple of 64 that is n^3/6 multiplies instead of n^3, and each 64x64 macro tile
//    fetches a column pair with two double2 loads per 4-wide k block. The k loop stops at the
//    end of the macro row block; the extra terms are the exact zeros of the upper-triangular M
//    and every entry keeps the original k = 0,1,2,... accumulation order. Tiles are swept in
//    strides of nt so any block size is handled.
// ---------------------------------------------------------------------------------------------
__device__ inline void pfinv_plane_f64(double* A, double* W, double* OUT, double* PF, int* ST, int n) {
  extern __shared__ char smem_raw[];
  double* xs = reinterpret_cast<double*>(smem_raw);  // n
  double* ys = xs + n;                               // n
  double* t1s = ys + n;                              // n
  double* t2s = t1s + n;                             // n
  double* vt = xs;                                   // n (phase 3 reuses xs)
  int* red_i = reinterpret_cast<int*>(t2s + n);      // 32 (also used as the inverse permutation)
  double* red_v = reinterpret_cast<double*>(red_i + 32);  // 32
  int* piv = reinterpret_cast<int*>(red_v + 32);     // n
  int* idx = piv + n;                                // n
  __shared__ int s_kp, s_info, s_zero, s_status;
  __shared__ double s_colmax;

  const int tid = threadIdx.x, nt = blockDim.x;
  const int lane = tid & 31, wid = tid >> 5, nw = nt >> 5;
  const size_t nn = (size_t)n * n;
  for (int i = tid; i < n; i += nt) piv[i] = i;
  if (tid == 0) s_info = 0;
  __syncthreads();

  // ---- Phase 1: LTL^T factorization, k0 = n-1 .. 1 (0-based), kk = k0-1 ----------------------
  for (int k0 = n - 1; k0 >= 1; --k0) {
    const int kk = k0 - 1;
    // First-index argmax of mag(A[0..kk, k0]) (same semantics as the scalar scan), reduced
    // warp-wise with shuffles and then across the warps.
    double bv = -1.0;
    int bi = 0x7fffffff;
    for (int j = tid; j <= kk; j += nt) {
      double v = fabs(A[j + (size_t)k0 * n]);
      if (v != v) v = (j == 0) ? 1e300 * 1e300 : -1.0;
      if (v > bv || (v == bv && j < bi)) { bv = v; bi = j; }
    }
    for (int s = 16; s > 0; s >>= 1) {
      double ov = __shfl_down_sync(0xffffffffu, bv, s);
      int oi = __shfl_down_sync(0xffffffffu, bi, s);
      if (ov > bv || (ov == bv && oi < bi)) { bv = ov; bi = oi; }
    }
    if (lane == 0) {
      red_v[wid] = bv;
      red_i[wid] = bi;
    }
    __syncthreads();
    if (tid == 0) {
      double v = red_v[0];
      int i0 = red_i[0];
      for (int w = 1; w < nw; ++w) {
        double ov = red_v[w];
        int oi = red_i[w];
        if (ov > v || (ov == v && oi < i0)) { v = ov; i0 = oi; }
      }
      int kp = i0;
      if (kp > kk) kp = kk;
      s_kp = kp;
      s_colmax = fabs(A[kp + (size_t)k0 * n]);
      s_zero = (s_colmax == 0.0) ? 1 : 0;
      if (s_zero) {
        if (s_info == 0) s_info = kk + 1;
      } else {
        piv[kk] = kp;
      }
    }
    __syncthreads();
    if (s_zero) continue;
    const int kp = s_kp;

    if (kp != kk) {
      for (int j = tid; j < kp; j += nt) {
        double t = A[j + (size_t)kk * n]; A[j + (size_t)kk * n] = A[j + (size_t)kp * n]; A[j + (size_t)kp * n] = t;
      }
      for (int j = kp + 1 + tid; j < kk; j += nt) {
        double t = A[j + (size_t)kk * n]; A[j + (size_t)kk * n] = A[kp + (size_t)j * n]; A[kp + (size_t)j * n] = t;
      }
      for (int j = k0 + tid; j < n; j += nt) {
        double t = A[kk + (size_t)j * n]; A[kk + (size_t)j * n] = A[kp + (size_t)j * n]; A[kp + (size_t)j * n] = t;
      }
      __syncthreads();
      for (int j = kp + tid; j < kk; j += nt) A[j + (size_t)kk * n] = -A[j + (size_t)kk * n];
      for (int j = kp + 1 + tid; j < kk; j += nt) A[kp + (size_t)j * n] = -A[kp + (size_t)j * n];
      __syncthreads();
    }

    if (kk >= 1) {
      const double alpha = 1.0 / A[kk + (size_t)k0 * n];
      // Stage the pivot columns and scale column k0 in one pass.
      for (int i = tid; i < kk; i += nt) {
        const double x = A[i + (size_t)k0 * n];
        const double y = A[i + (size_t)kk * n];
        xs[i] = x;
        ys[i] = y;
        t1s[i] = alpha * y;
        t2s[i] = alpha * x;
        A[i + (size_t)k0 * n] = alpha * x;
      }
      __syncthreads();
      // A_ij = (A_ij + x_i t1_j) - y_i t2_j over the strict upper triangle (i < j); the
      // diagonal is zeroed in the same sweep. Warp w handles columns j = w, w+nw, ... and all
      // of their rows in double2 chunks of 64 rows.
      {
        const int lane2 = lane << 1;
        for (int j = wid; j < kk; j += nw) {
          const double t1 = t1s[j], t2 = t2s[j];
          for (int base = 0; base < j; base += 64) {
            const int i = base + lane2;
            if (i + 1 < j) {
              const double2 x = *reinterpret_cast<const double2*>(xs + i);
              const double2 y = *reinterpret_cast<const double2*>(ys + i);
              double2 v = *reinterpret_cast<const double2*>(A + i + (size_t)j * n);
              v.x = (v.x + x.x * t1) - y.x * t2;
              v.y = (v.y + x.y * t1) - y.y * t2;
              *reinterpret_cast<double2*>(A + i + (size_t)j * n) = v;
            } else if (i < j) {
              const double v = (A[i + (size_t)j * n] + xs[i] * t1) - ys[i] * t2;
              A[i + (size_t)j * n] = v;
            }
          }
        }
        // Diagonal of the trailing block (the update only touches the strict upper triangle).
        for (int j = tid; j < kk; j += nt) A[j + (size_t)j * n] = 0.0;
      }
      __syncthreads();
    }
  }

  __syncthreads();

  // ---- Phase 2: Pfaffian and status ---------------------------------------------------------
  if (tid == 0) {
    int status = 0;
    double pf = 0.0;
    if (s_info > 0) {
      status = s_info;
    } else {
      pf = 1.0;
      for (int i = 0; i + 1 < n; i += 2) pf = pf * A[i + (size_t)(i + 1) * n];
      int flips = 0;
      for (int k = 0; k < n; ++k) flips += (piv[k] != k);
      if (flips & 1) pf = 0.0 - pf;
      if (!(pf - pf == 0.0)) status = -1;
    }
    s_status = status;
    PF[0] = pf;
    ST[0] = status;
  }
  __syncthreads();
  if (s_status != 0) {
    for (size_t e = tid; e < nn; e += nt) OUT[e] = 0.0;
    return;
  }

  // ---- Phase 3: inverse (utu2inv) -----------------------------------------------------------
  for (size_t e = tid; e < nn; e += nt) W[e] = 0.0;
  __syncthreads();
  for (int c = tid; c < n - 1; c += nt) {
    double* xc = W + (size_t)c * n;
    xc[c] = 1.0;
    for (int i = c - 1; i >= 0; --i) {
      double acc = 0.0;
      for (int k = i + 1; k <= c; ++k) acc = acc + A[i + (size_t)(k + 1) * n] * xc[k];
      xc[i] = 0.0 - acc;
    }
  }

  if (tid == 0) W[(n - 1) + (size_t)(n - 1) * n] = 1.0;
  for (int i = tid; i < n - 1; i += nt) vt[i] = -A[i + (size_t)(i + 1) * n];
  __syncthreads();
  for (int j = tid; j < n; j += nt) {
    const double* b = W + (size_t)j * n;
    double* c = A + (size_t)j * n;
    c[1] = b[0] / (-vt[0]);
    for (int i = 2; i < n; i += 2) c[i + 1] = (b[i] - c[i - 1] * vt[i - 1]) / (-vt[i]);
    c[n - 2] = b[n - 1] / vt[n - 2];
    for (int i = n - 3; i >= 1; i -= 2) c[i - 1] = (b[i] + c[i + 1] * vt[i]) / vt[i - 1];
  }
  if (tid == 0) {
    for (int i = 0; i < n; ++i) idx[i] = i;
    for (int j = 0; j < n; ++j) { int t = piv[j], a = idx[j]; idx[j] = idx[t]; idx[t] = a; }
    if (n % 64 == 0) {
      // inverse permutation in place of `piv` (no longer needed)
      for (int r = 0; r < n; ++r) piv[idx[r]] = r;
    }
  }
  __syncthreads();
  // Out[r,c] = sum_{k <= idx[r]} M[k, idx[r]] * C[k, idx[c]].
  //
  // Fast path (issue #517): n a multiple of 64. The product G = M^T C is skew, so only the
  // upper triangle G[i,j] (i <= j in pre-permutation indices) is computed and the transposed
  // entry is written as its exact negative. The 64x64 macro tiles use 4x4 register tiles per
  // thread with the k loop running to the end of the macro row block: the extra terms are the
  // exact zeros of the upper-triangular M, so each computed entry keeps the original
  // k = 0,1,2,... accumulation order. The two permuted output positions are written scattered;
  // that is n^2 single stores against n^3/6 multiplies. The macro tile holds 16x16 thread
  // tiles, swept in strides of nt so any block size is correct.
  if (n % 64 == 0) {
    const int* inv = piv;
    const int nm = n >> 6;
    for (int ma = 0; ma < nm; ++ma) {
      const int kmax = (ma + 1) << 6;
      for (int mb = ma; mb < nm; ++mb) {
        for (int tt = tid; tt < 256; tt += nt) {
          const int tx = tt >> 4, ty = tt & 15;
          if (mb == ma && ty < tx) continue;
          const int i0 = (ma << 6) + (tx << 2);
          const int j0 = (mb << 6) + (ty << 2);
          const double* wi = W + (size_t)i0 * n;
          const double* cj = A + (size_t)j0 * n;
          double g[4][4] = {{0.0, 0.0, 0.0, 0.0},
                             {0.0, 0.0, 0.0, 0.0},
                             {0.0, 0.0, 0.0, 0.0},
                             {0.0, 0.0, 0.0, 0.0}};
          // k blocks of 4: every column pair is fetched with two double2 loads, so each load
          // moves 32 contiguous bytes (16 column loads + 16 FMA per 64 multiplies) and the
          // accumulation order per output stays k = 0,1,2,3.
          for (int kb = 0; kb < kmax; kb += 4) {
            double2 w2[4][2], c2[4][2];
#pragma unroll
            for (int p = 0; p < 4; ++p) {
              w2[p][0] = *reinterpret_cast<const double2*>(wi + (size_t)p * n + kb);
              w2[p][1] = *reinterpret_cast<const double2*>(wi + (size_t)p * n + kb + 2);
            }
#pragma unroll
            for (int q = 0; q < 4; ++q) {
              c2[q][0] = *reinterpret_cast<const double2*>(cj + (size_t)q * n + kb);
              c2[q][1] = *reinterpret_cast<const double2*>(cj + (size_t)q * n + kb + 2);
            }
#pragma unroll
            for (int kk = 0; kk < 4; ++kk) {
              const double wv[4] = {kk < 2 ? (kk == 0 ? w2[0][0].x : w2[0][0].y)
                                           : (kk == 2 ? w2[0][1].x : w2[0][1].y),
                                    kk < 2 ? (kk == 0 ? w2[1][0].x : w2[1][0].y)
                                           : (kk == 2 ? w2[1][1].x : w2[1][1].y),
                                    kk < 2 ? (kk == 0 ? w2[2][0].x : w2[2][0].y)
                                           : (kk == 2 ? w2[2][1].x : w2[2][1].y),
                                    kk < 2 ? (kk == 0 ? w2[3][0].x : w2[3][0].y)
                                           : (kk == 2 ? w2[3][1].x : w2[3][1].y)};
              const double cv[4] = {kk < 2 ? (kk == 0 ? c2[0][0].x : c2[0][0].y)
                                           : (kk == 2 ? c2[0][1].x : c2[0][1].y),
                                    kk < 2 ? (kk == 0 ? c2[1][0].x : c2[1][0].y)
                                           : (kk == 2 ? c2[1][1].x : c2[1][1].y),
                                    kk < 2 ? (kk == 0 ? c2[2][0].x : c2[2][0].y)
                                           : (kk == 2 ? c2[2][1].x : c2[2][1].y),
                                    kk < 2 ? (kk == 0 ? c2[3][0].x : c2[3][0].y)
                                           : (kk == 2 ? c2[3][1].x : c2[3][1].y)};
#pragma unroll
              for (int p = 0; p < 4; ++p)
#pragma unroll
                for (int q = 0; q < 4; ++q) g[p][q] = g[p][q] + wv[p] * cv[q];
            }
          }
          const int ris[4] = {inv[i0], inv[i0 + 1], inv[i0 + 2], inv[i0 + 3]};
          const int cis[4] = {inv[j0], inv[j0 + 1], inv[j0 + 2], inv[j0 + 3]};
          for (int p = 0; p < 4; ++p) {
            for (int q = 0; q < 4; ++q) {
              const int i = i0 + p, j = j0 + q;
              if (i > j) continue;
              OUT[ris[p] + (size_t)cis[q] * n] = g[p][q];
              if (i < j) OUT[cis[q] + (size_t)ris[p] * n] = 0.0 - g[p][q];
            }
          }
        }
      }
    }
    __syncthreads();
    return;
  }
  for (int e = tid; e < n * n; e += nt) {
    const int r = e % n, c = e / n;
    const int ir = idx[r], ic = idx[c];
    double acc = 0.0;
    for (int k = 0; k <= ir; ++k) acc = acc + W[k + (size_t)ir * n] * A[k + (size_t)ic * n];
    OUT[r + (size_t)c * n] = acc;
  }

}

template <typename T>
__device__ inline void entry(T* A, T* W, T* OUT, T* PF, int* ST, int n) {
  const size_t p = blockIdx.x;
  pfinv_plane<T>(A + p * (size_t)n * n, W + p * (size_t)n * n, OUT + p * (size_t)n * n, PF + p, ST + p, n);
}

// Real-double body of the batched entry points: n >= 64 keeps the small-n batches on the generic
// path (bit-identical to the pre-#517 kernel there); odd n has no 16-byte-aligned double2 staging
// and stays generic as well.
__device__ inline void body_f64(double* A, double* W, double* OUT, double* PF, int* ST, int n) {
  if (n >= 64 && n < 128 && (n & 1) == 0) {
    const size_t p=blockIdx.x, nn=(size_t)n*n;
    pfinv_panel_plane<PfinvRealPanelOps>(A+p*nn,W+p*nn,OUT+p*nn,PF+p,ST+p,n);
  } else if (n >= 64 && (n & 1) == 0) {
    pfinv_plane_f64(A + blockIdx.x * (size_t)n * n, W + blockIdx.x * (size_t)n * n,
                    OUT + blockIdx.x * (size_t)n * n, PF + blockIdx.x, ST + blockIdx.x, n);
  } else {
    entry<double>(A, W, OUT, PF, ST, n);
  }
}

// Real n>=128 resident rebuilds already use the faster Julia paired kernel,
// followed by this file's independent C-order fallback for projection
// cancellation. Keep that fallback; the new real panel wins below n=128.
__device__ inline void body_c64(Cx<double>* A,Cx<double>* W,Cx<double>* OUT,Cx<double>* PF,int* ST,int n) {
  if (n>=64 && !(n&1)) {
    const size_t p=blockIdx.x, nn=(size_t)n*n;
    pfinv_panel_plane<PfinvComplexPanelOps>(reinterpret_cast<rcx*>(A+p*nn),
        reinterpret_cast<rcx*>(W+p*nn),reinterpret_cast<rcx*>(OUT+p*nn),
        reinterpret_cast<rcx*>(PF+p),ST+p,n);
  } else entry<Cx<double>>(A,W,OUT,PF,ST,n);
}

extern "C" __global__ void __launch_bounds__(256, 2) pfinv_f64(double* A, double* W, double* OUT, double* PF, int* ST, int n) {
  body_f64(A, W, OUT, PF, ST, n);
}

// Wide-block variant of `pfinv_f64` (issue #517 sampler hops): identical math, one 1024-thread
// block per plane instead of 256 threads with two blocks per SM. Phase 1's per-step rank-2 sweep
// is latency-bound, so a batch that under-uses the device (the sampler's recompute is 8 planes =
// 8 SMs out of 108) runs 1.2-1.6x faster; the saturated large batches prefer `pfinv_f64`
// (measured in `bench_recompute_roofline`; see docs/design/gpu-readiness.md 16.10).
extern "C" __global__ void __launch_bounds__(1024, 1) pfinv_f64_wide(double* A, double* W, double* OUT, double* PF, int* ST, int n) {
  body_f64(A, W, OUT, PF, ST, n);
}
extern "C" __global__ void pfinv_c64(Cx<double>* A, Cx<double>* W, Cx<double>* OUT, Cx<double>* PF, int* ST, int n) {
  body_c64(A, W, OUT, PF, ST, n);
}
extern "C" __global__ void pfinv_f32(float* A, float* W, float* OUT, float* PF, int* ST, int n) {
  entry<float>(A, W, OUT, PF, ST, n);
}
extern "C" __global__ void pfinv_c32(Cx<float>* A, Cx<float>* W, Cx<float>* OUT, Cx<float>* PF, int* ST, int n) {
  entry<Cx<float>>(A, W, OUT, PF, ST, n);
}

__device__ void PfinvRealPanelOps::reference(double* A,double* W,double* OUT,double* PF,int* ST,int n) {
  if (n>=64 && !(n&1)) pfinv_plane_f64(A,W,OUT,PF,ST,n);
  else pfinv_plane<double>(A,W,OUT,PF,ST,n);
}
__device__ void PfinvComplexPanelOps::reference(rcx* A,rcx* W,rcx* OUT,rcx* PF,int* ST,int n) {
  pfinv_plane<Cx<double>>(reinterpret_cast<Cx<double>*>(A),reinterpret_cast<Cx<double>*>(W),
      reinterpret_cast<Cx<double>*>(OUT),reinterpret_cast<Cx<double>*>(PF),ST,n);
}

// Julia-mVMC 47452f9, cuda_delayed_sampling.jl: four-update queue, retaining
// the unit-vector correction separately:
// M += u v^T - v u^T + e_a v^T - v e_a^T. Every return flushes the queue.
// Each walker owns its vector packet and uses the factorization output as a
// second inverse buffer during sampling; the two lifetimes never overlap.
#ifndef SLT
#define SLT(tab, qp, row, col, n2) ((tab)[(((size_t)(qp) * (n2)) + (row)) * (n2) + (col)])
#endif
enum { INTERVAL_DELAY = 4 };

__device__ double interval_warp_sum(double value) {
  for (int d=16; d; d>>=1) value += __shfl_down_sync(0xffffffff,value,d);
  return __shfl_sync(0xffffffff,value,0);
}

__device__ double interval_delayed_entry(const double* inv, const double* data,
    const int* sites, int count, int i, int j, int n) {
  if (i==j) return 0.;
  int row=min(i,j),col=max(i,j);
  double value=inv[(size_t)row*n+col];
  const double* u=data;const double* v=u+INTERVAL_DELAY*n;
  for (int k=0; k<count; ++k) {
    value=fma(u[k*n+row],v[k*n+col],fma(-u[k*n+col],v[k*n+row],value));
    if (col==sites[k]) value-=v[k*n+row];
    if (row==sites[k]) value+=v[k*n+col];
  }
  return i<j?value:-value;
}

__device__ void interval_delayed_ratio(const double* inv, double* data,
    const int* sites, int count, const double* row, const int* rs,
    int n, int a, int lane, double pf, double* candidate) {
  double ratio=0.;
  for (int j=lane; j<n; j+=32) ratio=fma(inv[(size_t)a*n+j],row[rs[j]],ratio);
  ratio=interval_warp_sum(ratio);
  const double* u=data;const double* v=u+INTERVAL_DELAY*n;
  double* dots=data+2*INTERVAL_DELAY*n;
  for (int k=0; k<count; ++k) {
    double udot=0.,vdot=0.;
    for (int j=lane; j<n; j+=32) {
      double x=row[rs[j]];
      udot=fma(u[k*n+j],x,udot);vdot=fma(v[k*n+j],x,vdot);
    }
    udot=interval_warp_sum(udot);vdot=interval_warp_sum(vdot);
    if (!lane) {
      udot+=row[rs[sites[k]]];dots[2*k]=udot;dots[2*k+1]=vdot;
      ratio=fma(u[k*n+a],vdot,fma(-v[k*n+a],udot,ratio));
      if (a==sites[k]) ratio+=vdot;
    }
  }
  if (!lane) {dots[2*INTERVAL_DELAY]=ratio;*candidate=-ratio*pf;}
}

__device__ void interval_delayed_update(const double* inv, double* data,
    const int* sites, int count, const double* tab, int qp, const int* rs,
    int n, int n2, int a, double* v1, double* v2, double* v3,
    int tid, int nt, bool active) {
  double* u=data;double* v=u+INTERVAL_DELAY*n;
  const double* dots=v+INTERVAL_DELAY*n;
  if (active) for (int j=tid; j<n; j+=nt) v3[j]=SLT(tab,qp,rs[a],rs[j],n2);
  __syncthreads();
  if (active) for (int i=tid; i<n; i+=nt) {
    double value=0.;
    if (i==a) value=dots[2*INTERVAL_DELAY];
    else {
      for (int j=0; j<n; ++j) value=fma(-inv[(size_t)j*n+i],v3[j],value);
      for (int k=0; k<count; ++k) {
        value=fma(u[k*n+i],dots[2*k+1],fma(-v[k*n+i],dots[2*k],value));
        if (i==sites[k]) value+=dots[2*k+1];
      }
    }
    v1[i]=value;
    v2[i]=interval_delayed_entry(inv,data,sites,count,a,i,n);
  }
  __syncthreads();
  if (active) {
    double scale=-1./v1[a];
    for (int i=tid; i<n; i+=nt) {u[count*n+i]=v1[i];v[count*n+i]=v2[i]*scale;}
  }
  __syncthreads();
}

__device__ void interval_delayed_flush(double*& inv, double*& alternate,
    const double* data, const int* sites, int count, int n, int nq, int tid, int nt) {
  if (!count) return;
  int packet=2*INTERVAL_DELAY*n+2*INTERVAL_DELAY+1;
  size_t nn=(size_t)n*n;
  for (size_t e=tid; e<nn*nq; e+=nt) {
    int q=e/nn,k=e%nn;
    alternate[e]=interval_delayed_entry(inv+q*nn,data+q*packet,sites,count,k/n,k%n,n);
  }
  __syncthreads();
  double* old=inv;inv=alternate;alternate=old;
}

#ifndef SLT
#define SLT(tab, qp, row, col, n2) ((tab)[(((size_t)(qp) * (n2)) + (row)) * (n2) + (col)])
#endif

// Device-resident interval sampler (issue #547).
//
// One block advances one walker's configuration for a whole interval of ordinary
// hopping proposals on the device, with the candidate selection, the Gutzwiller/Jastrow
// projection delta and the Metropolis decision all on the device. This removes the
// per-hop host<->device round trip that dominates the production lock-step sampler
// (`k_propose`/`k_accept` driven once per hop from the host).
//
// The legacy entry retains `k_propose` / `k_accept`'s separate products and
// ordered sums. At n >= 128 the resident entry follows Julia GPU's FMA
// arithmetic and four queued rank-two updates with warp-reduced ratios. The
// supplied tape, projection delta and log-space decision contract are shared.
//
// Proposal contract: the tape is the Julia GPU sampler's device tape
// (MVMCOptimizers.jl/ext/cuda_sampling_update.jl:cached_sampling_kernel!), so a tape can be
// shared with `gpu_sample!(s; tape=...)` for parity. A device u32 tape of 5 words per step,
// laid out [word][walker][step] (word-fastest, then walker, then step), linear index
// 5*(w + W*step) + word:
//   w0 -> source electron slot index: mi = w0 % ne
//   w1 -> spin sector (top bit): spin = w1 >> 31
//   w2 -> hop: destination rank among the empty sites of that spin without a local spin
//         (the Julia `empty_destinations` proposal, the default for nsite >= 64);
//         exchange: opposite-spin partner slot, w2 % ne
//   w3 -> exchange threshold: exchange = w3/2^32 < exchange_fraction (Julia GPU
//         0 / 0.5 / 1 for NExUpdatePath 0 / 1 / 2, cuda_runners.jl:52-58)
//   w4 -> acceptance uniform: u = w4 / 2^32, accept when log(u) < logratio
//   Every step consumes exactly 5 words, valid or not, so the tape length is fixed and
//   decision independent.
//
// Local spins and exchanges follow cuda_sampling_update.jl:215-341 and exist only on
// the resident entry; the legacy entry is hopping-only without local spins. A hop
// from a local-spin site is invalid. An exchange swaps an electron with an
// opposite-spin partner when both sites are singly occupied. Its overlap is
// recomputed from full Pfaffians and an accept refactors the walker, as Julia does.
// The projection counts (doublons, charges) are unchanged by an exchange.
//
// FSZ walkers (general orbitals, #714) extend the contract. A slot stores its
// rs = site + spin*nsite and carries its spin (C EleIdx/EleSpn):
//   w0 -> slot mi = w0 % n (any of the 2Ne electrons)
//   w1 -> 2Sz=-1 hop kind (top bit, C's genrand_real2() < 0.5 in
//         vmcmake_fsz.c): 0 hop to any empty non-local (site, spin)
//         (makeCandidate_hopping_fsz), 1 in-place conduction spin flip
//         (makeCandidate_LocalSpinFlip_conduction); unused for 2Sz >= 0,
//         whose hop keeps the slot's spin (makeCandidate_hopping_csz)
//   w2 -> hop: destination rank among those empty destinations;
//         exchange: partner slot w2 % n, valid when it has the opposite spin
//         and both sites are singly occupied (makeCandidate_exchange_fsz)
//   w3 -> update type, C getUpdateType with one uniform u3 = w3/2^32:
//         exchange if u3 < exchange_fraction, local spin flip if
//         u3 < exchange_fraction + flip_fraction, hop otherwise. A local spin
//         flip turns the slot's spin in place and is valid on a local-spin
//         site (makeCandidate_LocalSpinFlip_localspin).
//   w4 -> as above.
// An invalid proposal is skipped, so each proposal stays symmetric; C redraws
// until a candidate is valid instead. The projection ratio of an on-site flip
// is exactly one (C UpdateProjCnt_fsz). Only real tables are handled here; the
// caller rejects complex FSZ.

// ---------------------------------------------------------------------------------------------
// One-electron rank-one ratio for one QP plane: r = -pf_qp * sum_j inv[msa*n+j] * S[rsa][rs[j]].
// `rs[j]` is the candidate site index (spin offset included). Parallel products, serial sum.
// ---------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------
// One-electron rank-two inverse update (the k_accept `!two` branch) for one QP plane.
// ---------------------------------------------------------------------------------------------
// All groups reach every block barrier, including an inactive final QP tile.
// Immediate updates retain the original separate products and ascending-j order.
__device__ inline void interval_hop_update(double* invq, const double* tab, int qp, const int* rs,
                                           int n, int n2, int msa, double* v1, double* v2,
                                           double* v3, int tid, int nt, bool active) {
  const int rsa = rs[msa];
  if (active) {
    for (int j = tid; j < n; j += nt) v3[j] = SLT(tab, qp, rsa, rs[j], n2);
  }
  __syncthreads();
  if (active) {
    for (int i = tid; i < n; i += nt) {
      double acc = 0.0;
#pragma unroll 8
      for (int j = 0; j < n; ++j) acc += -invq[(size_t)j * n + i] * v3[j];
      v1[i] = acc;
    }
  }
  __syncthreads();
  if (active) {
    const double inv_vec1_a = -1.0 / v1[msa];
    for (int i = tid; i < n; i += nt) v2[i] = invq[(size_t)msa * n + i] * inv_vec1_a;
  }
  __syncthreads();
  if (active) {
    const int warp = tid >> 5, lane = tid & 31, nwarp = nt >> 5;
    for (int i = warp; i < n; i += nwarp) {
      const double vi1 = v1[i], vi2 = v2[i];
      const int rowoff = i * n;
      for (int j = lane; j < n; j += 32) {
        const int e = rowoff + j;
        double x = invq[e];
        x += vi1 * v2[j] - v1[j] * vi2;
        if (j == msa) x -= vi2;
        if (i == msa) x += v2[j];
        invq[e] = x;
      }
    }
  }
  __syncthreads();
}

// ---------------------------------------------------------------------------------------------
// Gutzwiller/Jastrow projection delta of a hop ri -> rj, using the post-hop occupancy
// `occ` ([site] up then [nsite+site] down). Collapses update_proj_cnt + log_proj_ratio:
// only the touched counters change, so the delta is
//   sum_i params[i] * (new_count[i] - old_count[i]).
// ---------------------------------------------------------------------------------------------
__device__ inline double interval_proj_delta(const int* occ, int nsite, int ngutz, int nproj,
                                             const int* gutz, const int* jast,
                                             const double* params, int ri, int rj) {
  double delta = 0.0;
  const int n0ri = occ[ri], n1ri = occ[nsite + ri];
  const int n0rj = occ[rj], n1rj = occ[nsite + rj];
  if (ngutz > 0) {
    if (gutz != nullptr) {
      const int ii = gutz[ri];
      if (ii >= 0 && ii < nproj) delta -= params[ii] * (double)(n0ri + n1ri);
      const int ij = gutz[rj];
      if (ij >= 0 && ij < nproj) delta += params[ij] * (double)(n0rj * n1rj);
    } else if (nproj > 0) {
      delta += params[0] * (double)(n0rj * n1rj - (n0ri + n1ri));
    }
  }
  if (jast != nullptr) {
    const int offset = ngutz;
    const int xi_ri = n0ri + n1ri, xi_rj = n0rj + n1rj;
    const int a = ri < rj ? ri : rj, b = ri < rj ? rj : ri;
    const int idx = jast[a * nsite + b];
    if (idx >= 0 && offset + idx < nproj) {
      delta += params[offset + idx] * (double)(xi_ri - xi_rj + 1);
    }
    for (int rk = 0; rk < nsite; ++rk) {
      if (rk == ri || rk == rj) continue;
      const double x = (double)(occ[rk] + occ[nsite + rk] - 1);
      if (x == 0.0) continue;
      const int a1 = ri < rk ? ri : rk, b1 = ri < rk ? rk : ri;
      const int ia = jast[a1 * nsite + b1];
      if (ia >= 0 && offset + ia < nproj) delta -= params[offset + ia] * x;
      const int a2 = rj < rk ? rj : rk, b2 = rj < rk ? rk : rj;
      const int ib = jast[a2 * nsite + b2];
      if (ib >= 0 && offset + ib < nproj) delta += params[offset + ib] * x;
    }
  }
  return delta;
}

// One proposal of the five-word tape (see the header): the normal Julia GPU
// contract, or the FSZ extension (#714). Thread 0 only; reads the walker's
// configuration and occupancy and changes nothing. `from`/`to` (and the
// exchange partner's `pfrom`/`pto`) are rs = site + spin*nsite positions.
struct ResidentMove {
  int valid, msa, exchange, partner, from, to, pfrom, pto;
};

__device__ inline ResidentMove resident_propose(const unsigned int* t, const int* ele_w,
                                                const int* occ_w, const int* loc, int n, int ne,
                                                int nsite, double exchange_p,
                                                double flip_fraction, int fsz, int spin_free) {
  int valid = 0, msa = 0, exchange = 0, partner = -1, from = 0, to = 0, pfrom = 0, pto = 0;
  if (fsz) {
    // FSZ contract (#714): the slot is w0 % 2Ne and carries its spin.
    msa = (int)(t[0] % (unsigned)n);
    from = ele_w[msa];
    const int ri = from % nsite, s = from / nsite;
    const double u3 = (double)t[3] / 4294967296.0;
    exchange = u3 < exchange_p;
    // exchange_p + flip_fraction is a dyadic sum (0.5 for paths 2 and 3).
    const int localflip = !exchange && u3 < exchange_p + flip_fraction;
    if (localflip) {
      // C makeCandidate_LocalSpinFlip_localspin: turn a local spin.
      to = ri + (1 - s) * nsite;
      valid = loc != nullptr && loc[ri] == 1 && occ_w[to] == 0;
    } else if (exchange) {
      // C makeCandidate_exchange_fsz: an opposite-spin partner (w2 % 2Ne),
      // both sites singly occupied.
      partner = (int)(t[2] % (unsigned)n);
      pfrom = ele_w[partner];
      const int rj = pfrom % nsite;
      valid = pfrom / nsite == 1 - s && occ_w[ri + (1 - s) * nsite] == 0 &&
              occ_w[rj + s * nsite] == 0;
      to = rj + s * nsite;
      pto = ri + (1 - s) * nsite;
    } else if (spin_free && (t[1] >> 31)) {
      // 2Sz=-1, C makeCandidate_LocalSpinFlip_conduction (word 1's top bit
      // is C's genrand_real2() >= 0.5): flip an itinerant spin in place.
      to = ri + (1 - s) * nsite;
      valid = (loc == nullptr || loc[ri] == 0) && occ_w[to] == 0;
    } else {
      // Rank w2 among the empty non-local destinations: any (site, spin)
      // for 2Sz=-1 (C makeCandidate_hopping_fsz), the slot's spin
      // otherwise (makeCandidate_hopping_csz).
      const int lo = spin_free ? 0 : s * nsite, hi = spin_free ? 2 * nsite : lo + nsite;
      int count = 0;
      for (int r = lo; r < hi; ++r) {
        if (occ_w[r] == 0 && (loc == nullptr || loc[r % nsite] == 0)) ++count;
      }
      valid = count > 0 && (loc == nullptr || loc[ri] == 0);
      if (count > 0) {
        int rank = (int)(t[2] % (unsigned)count);
        for (int r = lo; r < hi; ++r) {
          if (occ_w[r] == 0 && (loc == nullptr || loc[r % nsite] == 0)) {
            if (rank == 0) {
              to = r;
              break;
            }
            --rank;
          }
        }
      }
    }
  } else {
    const int mi = (int)(t[0] % (unsigned)ne);
    const int spin = (int)(t[1] >> 31);
    const int ri = ele_w[mi + spin * ne];
    exchange = (double)t[3] / 4294967296.0 < exchange_p;
    int rj = 0;
    if (exchange) {
      // Julia: partner of the other spin; neither site may hold the moved spin's
      // counterpart (cuda_sampling_update.jl:269-279).
      partner = (int)(t[2] % (unsigned)ne) + (1 - spin) * ne;
      rj = ele_w[partner];
      valid = ri != rj && occ_w[rj + spin * nsite] == 0 && occ_w[ri + (1 - spin) * nsite] == 0;
    } else {
      // empty_hopping_destination: empty sites of this spin without a local spin.
      int count = 0;
      for (int r = 0; r < nsite; ++r) {
        if (occ_w[r + spin * nsite] == 0 && (loc == nullptr || loc[r] == 0)) ++count;
      }
      valid = count > 0 && (loc == nullptr || loc[ri] == 0);
      if (count > 0) {
        int rank = (int)(t[2] % (unsigned)count);
        for (int r = 0; r < nsite; ++r) {
          if (occ_w[r + spin * nsite] == 0 && (loc == nullptr || loc[r] == 0)) {
            if (rank == 0) {
              rj = r;
              break;
            }
            --rank;
          }
        }
      }
    }
    msa = mi + spin * ne;
    from = ri + spin * nsite;
    to = rj + spin * nsite;
    pfrom = rj + (1 - spin) * nsite;
    pto = ri + (1 - spin) * nsite;
  }
  return ResidentMove{valid, msa, exchange, partner, from, to, pfrom, pto};
}

// ---------------------------------------------------------------------------------------------
// The fused interval kernel. One block per walker; `threads` should be >= n (clamped).
//
// State (per walker, resident across calls):
//   ele  [W][n]          configuration (site index per electron slot)
//   occ  [W][2*nsite]    occupancy (ele_num)
//   inv  [W][nqp][n*n]   mVMC inverse (invM = -X^-1)
//   pf   [W][nqp]        Pfaffians
//   aw   [W]             accepted moves since the last rebuild (in/out)
//   logip[W]             cached log|inner product| (in/out)
//
// Returns (per walker, written by thread 0):
//   hops_done[W]   hops actually advanced (< max_hops when a rebuild was requested)
//   rebuild[W]     1 when `aw` passed `nsite`, or an accepted move has a zero/nonfinite
//                  candidate plane Pfaffian (host must recompute before continuing)
//
// Shared memory: aligned n ints, nqp+1 doubles, reusable ratio/update scratch, 8 ints.
// ---------------------------------------------------------------------------------------------
template <bool resident = false>
__device__ __forceinline__ void interval_hop_impl(
    int* ele, int* occ, double* inv, double* pf, int* aw, double* logip,
    const double* slater, const double* weights, const int* gutz, const int* jast,
    const double* params, const unsigned int* tape, int total_hops, int* hop_off,
    int n, int ne, int nsite, int nqp, int qp_groups, int ngutz, int nproj, double exchange_fraction,
    int* hops_done, int* rebuild, int* accepts, double* delayed = nullptr, double* flush = nullptr,
    int* valid = nullptr, double* fac = nullptr, double* work = nullptr, int* error = nullptr,
    const int* loc = nullptr, const int* dh = nullptr, int n2dh = 0, int n4dh = 0,
    const int* rbm = nullptr, const double* rbmw = nullptr, double* theta = nullptr,
    int nneuron = 0, int fsz = 0, int spin_free = 0, double flip_fraction = 0.0) {
  extern __shared__ char smem_raw[];
  int* rs = reinterpret_cast<int*>(smem_raw);
  double* sh = reinterpret_cast<double*>(rs + ((n + 1) & ~1));
  double* pfnew = sh;        // [nqp]
  double* out = sh + nqp;    // [1]
  double* scratch = out + 1;
  const int w = blockIdx.x;
  const int tid = threadIdx.x, nt = blockDim.x;
  const int nwarp = nt >> 5;
  const int ratio_vectors = nwarp < nqp ? nwarp : nqp;
  const int scratch_vectors = ratio_vectors > 3 * qp_groups ? ratio_vectors : 3 * qp_groups;
  int* mvw = reinterpret_cast<int*>(scratch + (size_t)scratch_vectors * n);  // [8]
  const int group_threads = nt / qp_groups;
  const int group = tid / group_threads, group_tid = tid % group_threads;
  double* v1 = scratch + (size_t)group * 3 * n;
  double* v2 = v1 + n;
  double* v3 = v2 + n;

  const int n2 = 2 * nsite;
  const double* tab = slater;
  int* ele_w = ele + (size_t)w * n;
  int* occ_w = occ + (size_t)w * 2 * nsite;
  double* inv_w = inv + (size_t)w * nqp * n * n;
  double* pf_w = pf + (size_t)w * nqp;
  const bool queue = resident && delayed != nullptr;
  const int packet = 2*INTERVAL_DELAY*n+2*INTERVAL_DELAY+1;
  double* delay_w = queue ? delayed+(size_t)w*nqp*packet : nullptr;
  double* original_inv = inv_w;
  double* alternate = queue ? flush+(size_t)w*nqp*n*n : nullptr;
  int* sites = mvw+8;
  int pending = 0;
  // Julia tape layout [word][walker][step]: 5*(walker + walkers*step) + word.
  const unsigned int* tape_w = tape + (size_t)w * 5;
  const size_t tape_stride = 5 * (size_t)gridDim.x;

  // Per-plane recovery (#573) on the resident path: a walker with an invalid
  // plane proposes with full Pfaffians and refactors in this kernel on every
  // accept, as Julia's cached sampler does (cuda_sampling_update.jl:291-371).
  const bool recover = resident && valid != nullptr;
  int* valid_w = recover ? valid + (size_t)w * nqp : nullptr;
  double* fac_w = recover ? fac + (size_t)w * nqp * n * n : nullptr;
  double* work_w = recover ? work + (size_t)w * nqp * n * n : nullptr;
  // Exchanges and local spins need the resident full-Pfaffian/refactor path.
  const double exchange_p = recover ? exchange_fraction : 0.0;
  if (!recover) loc = nullptr;
  // FSZ walkers (#714) store each slot's rs = site + spin*nsite, so the
  // Slater row needs no spin offset (split = n); normal walkers keep the
  // spin-major slot layout (split = ne).
  const int split = fsz ? n : ne;
  __shared__ int s_rank, s_exchange, s_partner, s_from, s_to, s_pfrom, s_pto;
  if (tid == 0) {
    int all = 1;
    if (recover) for (int q = 0; q < nqp; ++q) all &= valid_w[q] != 0;
    s_rank = all;
  }
  __syncthreads();

  double log_old = logip[w];
  int window = aw[w];
  int advanced = 0;
  int accepted = 0;
  int need_rebuild = 0;
  mvw[6] = 0;
  const int start = hop_off[w];
  for (int hop = start; hop < total_hops; ++hop) {
    const unsigned int* t = tape_w + (size_t)hop * tape_stride;
    if (tid == 0) {
      const ResidentMove m = resident_propose(t, ele_w, occ_w, loc, n, ne, nsite, exchange_p,
                                              flip_fraction, fsz, spin_free);
      const int valid = m.valid, msa = m.msa, exchange = m.exchange, partner = m.partner;
      const int from = m.from, to = m.to, pfrom = m.pfrom, pto = m.pto;
      s_exchange = exchange;
      s_partner = partner;
      s_from = from;
      s_to = to;
      s_pfrom = pfrom;
      s_pto = pto;
      mvw[0] = valid;
      mvw[1] = msa;
    }
    __syncthreads();
    const int msa = mvw[1];
    const int exchange = s_exchange, partner = s_partner;
    const int from = s_from, to = s_to, pfrom = s_pfrom, pto = s_pto;
    // Sites and spin of the moved electron (normal walkers: spin is fixed).
    const int ri = from % nsite, rj = to % nsite, spin = from / nsite;
    if (!mvw[0]) {
      // Invalid proposals are frequent with local spins and exchanges: every
      // thread must read this step's move before thread 0 writes the next one.
      __syncthreads();
      ++advanced;
      continue;
    }
    if (tid == 0) {
      ele_w[msa] = fsz ? to : rj;
      occ_w[from] = 0;
      occ_w[to] = 1;
      if (exchange) {
        ele_w[partner] = fsz ? pto : ri;
        occ_w[pfrom] = 0;
        occ_w[pto] = 1;
      }
    }
    __syncthreads();
    for (int j = tid; j < n; j += nt) rs[j] = ele_w[j] + (j >= split ? nsite : 0);
    __syncthreads();

    if (resident && (!s_rank || exchange)) {
      // Julia cooperative_overlap!: every plane from the candidate sites.
      for (int q = 0; q < nqp; ++q) {
        resident_gather(fac_w, rs, n, -1, -1, tab, q, n2);
        const double p = resident_block_pfaffian(fac_w, n, scratch, scratch + n);
        if (tid == 0) pfnew[q] = p;
      }
      __syncthreads();
    } else {
      const int lane = tid & 31, warp = tid >> 5, nwarp = nt >> 5;
      for (int q = warp; q < nqp; q += nwarp) {
        const double* invq = inv_w + (size_t)q * n * n;
        double* sc = scratch + (size_t)warp * n;
        const int rsa = rs[msa];
        const double* row = tab + (((size_t)q * n2) + rsa) * n2;
        const double* inv_row = invq + (size_t)msa * n;
        if (queue) {
          interval_delayed_ratio(invq,delay_w+q*packet,sites,pending,row,rs,n,msa,lane,pf_w[q],pfnew+q);
        } else {
          for (int j = lane; j < n; j += 32) sc[j] = inv_row[j] * row[rs[j]];
          __syncwarp();
          if (lane == 0) {
            double ratio = 0.0;
#pragma unroll 8
            for (int j = 0; j < n; ++j) ratio += sc[j];
            pfnew[q] = -ratio * pf_w[q];
          }
        }
        __syncwarp();  // lane 0 must finish reading before the next QP reuses scratch
      }
      __syncthreads();
    }

    // Doublon-holon change of a hop (resident only; an exchange keeps every
    // site's charge, so no DH counter changes). Block-parallel over the DH
    // items, then a fixed-order warp and warp-partial reduction. The ratio
    // scratch is free here: the update reuses it only after the decision.
    double dh_delta = 0.0;
    if (resident && dh != nullptr && !exchange) {
      const ResidentOcc after{occ_w, nsite};
      const ResidentOccBeforeHop before{occ_w, nsite, ri, rj, spin};
      double part = resident_dh_delta(before, after, dh, n2dh, n4dh, nsite,
                                      nproj - 6 * n2dh - 10 * n4dh, params, tid, nt);
      for (int d = 16; d; d >>= 1) part += __shfl_down_sync(0xffffffff, part, d);
      if ((tid & 31) == 0) scratch[tid >> 5] = part;
      __syncthreads();
      if (tid == 0) for (int i = 0; i < nwarp; ++i) dh_delta += scratch[i];
    }

    // RBM log-ratio of the move (resident only): C UpdateRBMCnt applied to
    // the cached hidden fields, then LogRBMRatio. An exchange is C's two hops
    // (ri -> rj with spin s, then rj -> ri with 1-s, vmcmake.c:250-260).
    const bool use_rbm = resident && rbm != nullptr;
    double* theta_w = use_rbm ? theta + (size_t)w * nneuron : nullptr;
    const int hops = exchange ? 2 : 1;
    const int hop_i[2] = {ri, rj}, hop_j[2] = {rj, ri}, hop_s[2] = {spin, 1 - spin};
    double rbm_delta = 0.0;
    if (use_rbm) {
      __syncthreads();  // the DH reduction above may still be reading scratch
      double part = resident_rbm_hidden_delta(rbm, rbmw, theta_w, nsite, nneuron, hop_i, hop_j,
                                              hop_s, hops, tid, nt);
      for (int d = 16; d; d >>= 1) part += __shfl_down_sync(0xffffffff, part, d);
      if ((tid & 31) == 0) scratch[tid >> 5] = part;
      __syncthreads();
      if (tid == 0) {
        rbm_delta = resident_rbm_phys_delta(rbm, rbmw, nsite, hop_i, hop_j, hop_s, hops);
        for (int i = 0; i < nwarp; ++i) rbm_delta += scratch[i];
      }
    }

    if (tid == 0) {
      double ip_new = 0.0;
      for (int q = 0; q < nqp; ++q) ip_new = __dadd_rn(ip_new, __dmul_rn(weights[q], pfnew[q]));
      const double log_new = log(fabs(ip_new) + 1e-100);
      // An exchange keeps every site's charge and doublon count, and so does
      // an on-site FSZ spin flip (C UpdateProjCnt_fsz returns for ri == rj).
      const double proj = (exchange || ri == rj ? 0.0
          : interval_proj_delta(occ_w, nsite, ngutz, nproj, gutz, jast, params, ri, rj) + dh_delta)
          + rbm_delta;
      const double logratio = 2.0 * (proj + log_new - log_old);
      const double u = (double)t[4] / 4294967296.0;
      // Keep log-space decisions for finite overlaps (including u == 0 and
      // extreme ratios), but never publish an overflowed weighted sum (#564).
      const int accept = isfinite(ip_new) && ip_new != 0.0 && log(u) < logratio;
      mvw[5] = accept;
      // A finite nonzero total can hide a candidate plane whose Pfaffian is 0 or
      // nonfinite. Its rank-two update divides by that plane's ratio, so the
      // accept instead requests an immediate walker rebuild (Julia
      // cuda_sampling_update.jl:343-371). The rebuild latches a singular plane.
      // The resident path refactors in this kernel; the legacy host-driven
      // path returns a rebuild request instead.
      int singular = 0;
      if (accept && s_rank && !exchange) {
        for (int q = 0; q < nqp; ++q) singular |= !isfinite(pfnew[q]) || pfnew[q] == 0.0;
      }
      // Julia refactors after every accepted exchange (cuda_sampling_update.jl:341).
      mvw[7] = accept && (singular || !s_rank || exchange);
      if (accept) {
        out[0] = log_new;
      } else {
        ele_w[msa] = fsz ? from : ri;
        occ_w[from] = 1;
        occ_w[to] = 0;
        if (exchange) {
          ele_w[partner] = fsz ? pfrom : rj;
          occ_w[pfrom] = 1;
          occ_w[pto] = 0;
        }
      }
    }
    __syncthreads();
    // An accepted move advances every hidden field (C copies rbmCntNew).
    // Each thread rewrites the neurons it read above.
    if (use_rbm && mvw[5]) {
      for (int h = tid; h < nneuron; h += nt) {
        double t = theta_w[h];
        for (int k = 0; k < hops; ++k)
          t = resident_rbm_hop(rbm, rbmw, nsite, nneuron, h, t, hop_i[k], hop_j[k], hop_s[k]);
        theta_w[h] = t;
      }
    }
    if (mvw[5] && mvw[7] && recover) {
      // Queued updates belong to the replaced inverse; discard, do not flush.
      pending = 0;
      const int all = resident_refactor_walker(inv_w, pf_w, valid_w, rs, tab, n, nqp, n2,
                                               fac_w, work_w, scratch);
      if (tid == 0) {
        double ip = 0.0;
        for (int q = 0; q < nqp; ++q) ip = __dadd_rn(ip, __dmul_rn(weights[q], pf_w[q]));
        ++accepted;
        if (!isfinite(ip) || ip == 0.0) {
          atomicCAS(error, 0, RESIDENT_REBUILD);
          mvw[6] = 2;
        } else {
          log_old = log(fabs(ip) + 1e-100);
          window = 0;
        }
        s_rank = all;
      }
      __syncthreads();
    } else if (mvw[5] && mvw[7]) {
      // No inverse/Pfaffian update; the rebuild refactors the accepted configuration.
      if (tid == 0) {
        log_old = out[0];
        ++accepted;
        ++window;
        mvw[6] = 1;
      }
      __syncthreads();
    } else if (mvw[5]) {
      for (int base = 0; base < nqp; base += qp_groups) {
        const int q = base + group;
        const bool active = q < nqp;
        double* invq = active ? inv_w + (size_t)q * n * n : inv_w;
        if (queue)
          interval_delayed_update(invq,delay_w+(active?q:0)*packet,sites,pending,tab,q,rs,n,n2,msa,
                                  v1,v2,v3,group_tid,group_threads,active);
        else
          interval_hop_update(invq, tab, q, rs, n, n2, msa, v1, v2, v3,
                                    group_tid, group_threads, active);
        // Publish the Pfaffian with the pivot that updated this inverse. The
        // immediate path follows C UpdateMAll (PfM *= -vec1[msa]); the queue
        // pivots with the proposal ratio itself (Julia). Mixing the column
        // contraction pivot with the row-dot proposal ratio leaves an
        // unrecoverable error after a near-singular plane (#656).
        if (active && group_tid == 0) pf_w[q] = queue ? pfnew[q] : pf_w[q] * -v1[msa];
      }
      __syncthreads();
      if (queue) {
        if (tid == 0) sites[pending] = msa;
        __syncthreads();
        if (++pending == INTERVAL_DELAY) {
          interval_delayed_flush(inv_w,alternate,delay_w,sites,pending,n,nqp,tid,nt);
          pending = 0;
        }
      }
      if (tid == 0) {
        log_old = out[0];
        ++accepted;
        if (++window > nsite) mvw[6] = 1;
      }
      __syncthreads();
    }
    ++advanced;
    if (mvw[6]) {
      need_rebuild = mvw[6] == 1;  // 2: in-kernel refactor failed and latched
      break;
    }
  }

  if (queue) {
    interval_delayed_flush(inv_w,alternate,delay_w,sites,pending,n,nqp,tid,nt);
    if (inv_w != original_inv) {
      for (size_t e=tid; e<(size_t)nqp*n*n; e+=nt) original_inv[e]=inv_w[e];
      __syncthreads();
    }
  }
  if (tid == 0) {
    hop_off[w] = start + advanced;
    hops_done[w] = advanced;
    rebuild[w] = need_rebuild;
    accepts[w] = accepted;
    aw[w] = window;
    logip[w] = log_old;
  }
}

// Compile the common matrix side into the ordered loops and address arithmetic.
// Other geometries retain the same general kernel. No arithmetic is reassociated.
extern "C" __global__ void k_interval_hop(
    int* ele, int* occ, double* inv, double* pf, int* aw, double* logip,
    const double* slater, const double* weights, const int* gutz, const int* jast,
    const double* params, const unsigned int* tape, int total_hops, int* hop_off,
    int n, int ne, int nsite, int nqp, int qp_groups, int ngutz, int nproj, double exchange_fraction,
    int* hops_done, int* rebuild, int* accepts) {
  if (n == 128) {
    interval_hop_impl(
      ele, occ, inv, pf, aw, logip, slater, weights, gutz, jast, params, tape,
      total_hops, hop_off, 128, ne, nsite, nqp, qp_groups, ngutz, nproj,
      exchange_fraction, hops_done, rebuild, accepts);
  } else {
    interval_hop_impl(
      ele, occ, inv, pf, aw, logip, slater, weights, gutz, jast, params, tape,
      total_hops, hop_off, n, ne, nsite, nqp, qp_groups, ngutz, nproj,
      exchange_fraction, hops_done, rebuild, accepts);
  }
}

// Device-side rebuild helpers for the interval sampler (issue #547).
//
// Compiled together with `pfaffian_batched.cu` (`pfinv_f64`) and `interval_kernels.cu`
// (`SLT`). When a walker's accepted-move window passes `nsite`, the host batches every walker
// that needs a rebuild into one assemble + `pfinv_f64` + commit launch on tenferro's stream.
// This keeps the recomputation on the device instead of a per-walker host
// `calc_m_all_real`, which is the rebuild bottleneck at L=128.

// Assemble the skew plane `A[item][qp] = -S[qp][rs[msi]][rs[j]]` (the mVMC `calculateMAll`
// plane of the candidate configuration) for the walkers in `rec_walker`. One block per
// (item, qp); the element map matches `k_assemble` in sampler_kernels.cu.
extern "C" __global__ void interval_assemble(const int* rec_walker, const int* ele,
                                             const double* slater, double* A, int n, int ne,
                                             int nsite, int nqp) {
  const int item = blockIdx.x / nqp, qp = blockIdx.x % nqp;
  const int w = rec_walker[item];
  const int* e = ele + (size_t)w * n;
  const int n2 = 2 * nsite;
  double* plane = A + ((size_t)item * nqp + qp) * n * n;
  for (int idx = threadIdx.x; idx < n * n; idx += blockDim.x) {
    const int msi = idx / n, j = idx % n;
    const int rsi = e[msi] + (msi >= ne ? nsite : 0);
    const int rsj = e[j] + (j >= ne ? nsite : 0);
    plane[idx] = -SLT(slater, qp, rsi, rsj, n2);
  }
}

// Commit `pfinv_f64`'s output for the walkers in `rec_walker`: `invM = -OUT` (the
// `calc_m_all_real` sign flip), `pf = PF`, reset the accepted-move window and refresh the
// cached `log|inner product|`.
extern "C" __global__ void interval_commit(const int* rec_walker, const double* OUT,
                                           const double* PF, const double* weights, double* inv,
                                           double* pf, double* logip, int* aw, int n, int nqp) {
  const int item = blockIdx.x;
  const int w = rec_walker[item];
  const size_t plane = (size_t)n * n;
  for (size_t e = threadIdx.x; e < (size_t)nqp * plane; e += blockDim.x)
    inv[(size_t)w * nqp * plane + e] = -OUT[(size_t)item * nqp * plane + e];
  for (int q = threadIdx.x; q < nqp; q += blockDim.x)
    pf[(size_t)w * nqp + q] = PF[(size_t)item * nqp + q];
  __syncthreads();
  if (threadIdx.x == 0) {
    double ip = 0.0;
    for (int q = 0; q < nqp; ++q) ip = __dadd_rn(ip, __dmul_rn(weights[q], pf[(size_t)w * nqp + q]));
    logip[w] = log(fabs(ip) + 1e-100);
    aw[w] = 0;
  }
}

// Resident interval orchestration (#560). Rebuild flags never leave the device.
// A launch can accept at most one move per hop. After a rebuild the next one needs
// nsite+1 accepts, so the host can enqueue a bounded schedule without reading flags.

extern "C" __global__ void interval_resident_hop(
    int* ele, int* occ, double* inv, double* pf, int* aw, double* logip,
    const double* slater, const double* weights, const int* gutz, const int* jast,
    const double* params, const unsigned int* tape, int total_hops, int* hop_off,
    int n, int ne, int nsite, int nqp, int qp_groups, int ngutz, int nproj,
    int* hops_done, int* rebuild, int* accepts, int* total_accepts, int* error, double* delayed, double* flush, int delayed_updates,
    int* valid, double* fac, double* work, const int* loc, double exchange_fraction,
    const int* dh, int n2dh, int n4dh, const int* rbm, const double* rbmw, double* theta,
    int nneuron, int fsz, int spin_free, double flip_fraction) {
  if (*error) return;  // block-uniform; previous launch owns the error flag
  if (n == 128) {
    interval_hop_impl<true>(ele, occ, inv, pf, aw, logip, slater, weights, gutz, jast,
      params, tape, total_hops, hop_off, 128, ne, nsite, nqp, qp_groups, ngutz,
      nproj, exchange_fraction, hops_done, rebuild, accepts,
      n >= 128 && delayed_updates ? delayed : nullptr, flush, valid, fac, work, error, loc, dh, n2dh, n4dh, rbm, rbmw, theta, nneuron,
      fsz, spin_free, flip_fraction);
  } else {
    interval_hop_impl<true>(ele, occ, inv, pf, aw, logip, slater, weights, gutz, jast,
      params, tape, total_hops, hop_off, n, ne, nsite, nqp, qp_groups, ngutz,
      nproj, exchange_fraction, hops_done, rebuild, accepts,
      n >= 128 && delayed_updates ? delayed : nullptr, flush, valid, fac, work, error, loc, dh, n2dh, n4dh, rbm, rbmw, theta, nneuron,
      fsz, spin_free, flip_fraction);
  }
  // interval_hop_impl publishes accepts from thread 0 of the same block.
  if (threadIdx.x == 0) total_accepts[blockIdx.x] += accepts[blockIdx.x];
}

// Assemble and factor only a requested walker. No host-generated compact index
// list and no copying resident inverses/Pfaffians back for a rebuild. `ne` is
// the first slot with the down-spin offset: Ne for normal walkers, 2Ne for FSZ
// walkers, whose slots already hold rs (#714).
extern "C" __global__ void interval_resident_factor(
    const int* rebuild, const int* error, const int* ele, const double* slater,
    double* A, double* W, double* OUT, double* PF, int* ST,
    int n, int ne, int nsite, int nqp) {
  const int plane = blockIdx.x, w = plane / nqp, q = plane % nqp;
  if (*error || !rebuild[w]) return;
  const size_t offset = (size_t)plane * n * n;
  double* a = A + offset;
  const int* e = ele + (size_t)w * n;
  for (int index = threadIdx.x; index < n*n; index += blockDim.x) {
    const int i = index / n, j = index % n;
    const int ri = e[i] + (i >= ne ? nsite : 0);
    const int rj = e[j] + (j >= ne ? nsite : 0);
    a[index] = -SLT(slater, q, ri, rj, 2*nsite);
  }
  __syncthreads();
  body_f64(A, W, OUT, PF, ST, n);
}

// Publish a walker whose weighted overlap is finite and nonzero, recording
// per-plane validity as Julia does (cuda_batched_inverse.jl:68): no zero pivot
// and a finite nonzero Pfaffian. An invalid plane publishes Pf = 0 from the
// zero-pivot factor; no all-valid path reads its inverse storage. A zero or
// nonfinite total latches the sticky error, and every table of that walker
// retains its previous contents. Later sampling stops until the owner reports.
extern "C" __global__ void interval_resident_commit(
    const int* rebuild, int* error, const int* ST, const double* OUT,
    const double* PF, const double* weights, double* inv, double* pf,
    double* logip, int* aw, int* valid, int n, int nqp) {
  const int w = blockIdx.x;
  if (!rebuild[w]) return;
  __shared__ int good;
  __shared__ double log_overlap;
  if (threadIdx.x == 0) {
    double ip = 0.0;
    for (int q = 0; q < nqp; ++q)
      ip = __dadd_rn(ip, __dmul_rn(weights[q], PF[w*nqp+q]));
    good = isfinite(ip) && ip != 0.0;
    log_overlap = log(fabs(ip) + 1e-100);
    if (!good) atomicCAS(error, 0, RESIDENT_REBUILD);
  }
  __syncthreads();
  if (!good) return;
  const size_t base = (size_t)w*nqp*n*n;
  for (size_t i = threadIdx.x; i < (size_t)nqp*n*n; i += blockDim.x)
    inv[base+i] = -OUT[base+i];
  for (int q = threadIdx.x; q < nqp; q += blockDim.x) {
    const double p = PF[w*nqp+q];
    pf[w*nqp+q] = p;
    valid[w*nqp+q] = ST[w*nqp+q] == 0 && isfinite(p) && p != 0.0;
  }
  if (threadIdx.x == 0) {
    logip[w] = log_overlap;
    aw[w] = 0;
  }
}

// The host enqueues a bounded number of hop/rebuild rounds without reading
// flags. In-kernel refactors keep that bound; this guards the invariant so a
// walker with unfinished hops never publishes a short interval.
extern "C" __global__ void interval_resident_complete(
    const int* hop_off, int hops, int* error, int walkers) {
  const int w = blockIdx.x * blockDim.x + threadIdx.x;
  if (w < walkers && hop_off[w] < hops) atomicCAS(error, 0, RESIDENT_SCHEDULE);
}

// Paired skew elimination: P A P^T = U D U^T, with unit upper U and
// 2x2 skew diagonal blocks D. Adapted from Julia-mVMC 47452f9,
// cuda_paired_factor.jl (PFAPACK DSKTF2 provenance). A panel keeps K
// rank-two updates in shared memory; inverse construction grows by two columns.
// Used only by the Julia-compatible resident sampler. The C-order factorizer
// remains the independent fallback, including amplified projection cancellation.

__device__ double paired_entry(const double* a, int i, int j, int n,
                              const double* raw, int pending) {
  double value = a[i + (size_t)j*n];
  for (int p=0; p<pending; ++p) {
    const double* v = raw + (size_t)p*4*n;
    if (v[j] != 0.0 || v[n+j] != 0.0)
      value = fma(-v[n+i], v[3*n+j], fma(v[i], v[2*n+j], value));
  }
  return value;
}

extern "C" __global__ void __launch_bounds__(128, 2) interval_paired_factor(
    const int* rebuild, const int* error, const int* ele, const double* slater,
    double* A, double* W, double* OUT, double* PF, int* ST,
    int n, int ne, int nsite, int nqp, int capacity) {
  int plane=blockIdx.x, w=plane/nqp, q=plane%nqp;
  if (*error || !rebuild[w]) return;
  int tid=threadIdx.x, nt=blockDim.x, lane=tid%32;
  size_t offset=(size_t)plane*n*n;
  double* a=A+offset; double* b=W+offset; double* out=OUT+offset;
  const int* e=ele+(size_t)w*n;
  extern __shared__ char paired_mem[];
  double* raw=reinterpret_cast<double*>(paired_mem);
  double* diagonal=raw+4*n*capacity;
  int* piv=reinterpret_cast<int*>(diagonal+n/2);
  int* perm=piv+n;
  __shared__ int pivot, bad;
  __shared__ double alpha, sign;
  for (int k=tid; k<n*n; k+=nt) {
    int i=k%n, j=k/n;
    a[k]=SLT(slater,q,e[i]+(i>=ne?nsite:0),e[j]+(j>=ne?nsite:0),2*nsite);
  }
  for (int i=tid; i<n; i+=nt) piv[i]=i;
  if (!tid) { bad=0; sign=1.; }
  __syncthreads();
  int pending=0;
  for (int k=n-1; k>=1; k-=2) {
    int kk=k-1;
    if (pending) {
      for (int i=tid; i<k; i+=nt) a[i+(size_t)k*n]=paired_entry(a,i,k,n,raw,pending);
      __syncthreads();
    }
    if (tid<32) {
      double vmax=fabs(a[(size_t)k*n]); int kp=0;
      for (int j=lane; j<k; j+=32) {
        double v=fabs(a[j+(size_t)k*n]);
        if (v>vmax || (v==vmax && j<kp)) {vmax=v;kp=j;}
      }
      for (int d=16; d; d>>=1) {
        double v=__shfl_down_sync(0xffffffff,vmax,d);
        int j=__shfl_down_sync(0xffffffff,kp,d);
        if (v>vmax || (v==vmax && j<kp)) {vmax=v;kp=j;}
      }
      if (!tid) { pivot=kp; if (vmax==0. || !isfinite(vmax)) bad=k; }
    }
    __syncthreads();
    if (bad) break;
    int kp=pivot;
    if (kp!=kk) {
      for (int j=tid; j<kp; j+=nt) {
        double v=a[j+(size_t)kk*n]; a[j+(size_t)kk*n]=a[j+(size_t)kp*n]; a[j+(size_t)kp*n]=v;
      }
      for (int j=kp+1+tid; j<kk; j+=nt) {
        double v=a[j+(size_t)kk*n]; a[j+(size_t)kk*n]=a[kp+(size_t)j*n]; a[kp+(size_t)j*n]=v;
      }
      for (int j=k+tid; j<n; j+=nt) {
        double v=a[kk+(size_t)j*n]; a[kk+(size_t)j*n]=a[kp+(size_t)j*n]; a[kp+(size_t)j*n]=v;
      }
      for (int c=tid; c<4*pending; c+=nt) {
        double* v=raw+(size_t)c*n; double t=v[kk];v[kk]=v[kp];v[kp]=t;
      }
      __syncthreads();
      for (int j=kp+tid; j<kk; j+=nt) a[j+(size_t)kk*n]=-a[j+(size_t)kk*n];
      for (int j=kp+1+tid; j<kk; j+=nt) a[kp+(size_t)j*n]=-a[kp+(size_t)j*n];
      if (!tid) sign=-sign;
      __syncthreads();
    }
    if (pending) for (int i=tid; i<kk; i+=nt)
      a[i+(size_t)kk*n]=paired_entry(a,i,kk,n,raw,pending);
    if (!tid) alpha=1./a[kk+(size_t)k*n];
    __syncthreads();
    double* v=raw+(size_t)pending*4*n;
    for (int j=tid; j<kk; j+=nt) {
      double u=a[j+(size_t)kk*n], x=a[j+(size_t)k*n];
      v[j]=x;v[n+j]=u;v[2*n+j]=u*alpha;v[3*n+j]=x*alpha;
      a[j+(size_t)j*n]=0.;a[j+(size_t)kk*n]=x*alpha;a[j+(size_t)k*n]=-u*alpha;
    }
    if (!tid) {piv[kk]=kp;diagonal[k/2]=a[kk+(size_t)k*n];a[kk+(size_t)k*n]=0.;}
    __syncthreads();
    if (++pending==capacity) {
      for (int j=tid/32; j<kk; j+=nt/32)
        for (int i=lane; i<j; i+=32) a[i+(size_t)j*n]=paired_entry(a,i,j,n,raw,pending);
      __syncthreads();pending=0;
    }
  }
  if (!tid) {
    double pf=1.;
    if (!bad) for (int i=0; i<n/2; ++i) pf*=diagonal[i];
    pf*=sign;
    if (!isfinite(pf) || pf==0.) bad=-1;
    PF[plane]=bad?0.:pf;
  }
  __syncthreads();
  if (bad) { if (!tid) ST[plane]=bad;return; }

  // Reuse the panel for U's new columns and their products with the current
  // leading inverse. Each row keeps the Julia ascending-j FMA order.
  for (int k=0; k<n; k+=2) {
    for (int i=tid; i<k; i+=nt) {raw[i]=a[i+(size_t)k*n];raw[n+i]=a[i+(size_t)(k+1)*n];}
    __syncthreads();
    for (int i=tid; i<k; i+=nt) {
      double x=0.,y=0.;
      for (int j=0; j<k; ++j) {double value=b[i+(size_t)j*n];x=fma(value,raw[j],x);y=fma(value,raw[n+j],y);}
      raw[2*n+i]=x;raw[3*n+i]=y;
    }
    __syncthreads();
    for (int i=tid; i<k; i+=nt) {
      double x=raw[2*n+i],y=raw[3*n+i];
      b[i+(size_t)k*n]=-x;b[k+(size_t)i*n]=x;
      b[i+(size_t)(k+1)*n]=-y;b[k+1+(size_t)i*n]=y;
    }
    if (!tid) {
      double value=-1./diagonal[k/2];
      for (int i=0; i<k; ++i) value=fma(raw[i],raw[3*n+i],value);
      b[k+(size_t)k*n]=0.;b[k+1+(size_t)(k+1)*n]=0.;
      b[k+(size_t)(k+1)*n]=value;b[k+1+(size_t)k*n]=-value;
    }
    __syncthreads();
  }
  if (!tid) {
    for (int i=0; i<n; ++i) perm[i]=i;
    for (int j=0; j<n; ++j) {int t=perm[j];perm[j]=perm[piv[j]];perm[piv[j]]=t;}
  }
  __syncthreads();
  bool invalid=false;
  for (int k=tid; k<n*n; k+=nt) {
    double value=b[perm[k%n]+(size_t)perm[k/n]*n];out[k]=value;invalid |= !isfinite(value);
  }
  if (__syncthreads_or(invalid)) {if (!tid) bad=-1;}
  if (!tid) ST[plane]=bad;
}

// Projection can amplify per-sector roundoff. Repeat these walkers using the
// original factorizer, entirely on device, before the commit checks status.
extern "C" __global__ void interval_paired_fallback(
    const int* rebuild, const int* status, const double* pf, const double* weights,
    int* fallback, int walkers, int nq) {
  int w=blockIdx.x*blockDim.x+threadIdx.x;
  if (w>=walkers) return;
  if (!rebuild[w]) {fallback[w]=0;return;}
  bool bad=false;double ip=0.,scale=0.;
  for (int q=0; q<nq; ++q) {
    double p=pf[w*nq+q],term=weights[q]*p;
    ip+=term;scale+=fabs(term);bad |= status[w*nq+q]!=0 || !isfinite(p) || p==0.;
  }
  fallback[w]=bad || !isfinite(ip) || fabs(ip)*1024.<scale;
}

// Resident complex normal-orbital sampler and rebuild (#678, #572 milestone 6).
//
// Julia GPU has no complex path ("CUDA runner requires real parameters",
// ext/cuda_state.jl:39), so the physics follows C's complex normal path:
// CalculateMAll_fcmp (PFAPACK zsktf2/utu2pfa/utu2inv, here
// pfinv_plane<Cx<double>>), CalculateNewPfM2 and UpdateMAll_child_fcmp
// (pfupdate.c), CalculateLogIP_fcmp (qp.c, log|ip|) and the vmcmake.c
// acceptance exp(2 (Re(logIpNew - logIpOld) + LogProjRatio)). LogProjRatio
// uses the real projection parameters (projection.c creal(Proj)).
//
// The proposal and decision contract is the Julia GPU tape of
// interval_kernels.cu (five words per proposal, empty-destination hops,
// exchange threshold word 3, log-space acceptance with the 1e-100 overlap
// floor). Updates are immediate C rank-two updates (no delayed queue, no
// paired factor). The #573 per-plane validity is kept: a walker with an
// invalid plane or an exchange proposal scores the candidate with full
// complex Pfaffians, and such an accept, or an accept whose candidate plane
// Pfaffian is zero or nonfinite, refactors the walker in this kernel.
// Local spins, DH and RBM are rejected on the host in complex mode.
//
// Complex FSZ walkers (#714 (c), C vmcmake_fsz.c, pfupdate_fsz.c) hold rs
// per slot and use the FSZ proposals of resident_propose (interval_kernels.cu);
// a slot then needs no spin offset (split = n).

// Complex C UpdateMAll_child_fcmp for one QP plane, by the whole block:
// vec1 = -invM^T sltE_a, PfM *= -vec1[a], vec2 = invM_a / -vec1[a],
// invM += vec1 vec2^T - vec2 vec1^T with the unit-vector corrections.
template <bool Warp>
__device__ inline void interval_complex_update(rcx* invq, rcx* pfq, const rcx* tab, int qp,
                                               const int* rs, int n, int n2, int msa, rcx* v1,
                                               rcx* v2, rcx* v3) {
  const int tid = Warp ? (threadIdx.x & 31) : threadIdx.x;
  const int nt = Warp ? 32 : blockDim.x;
  const int rsa = rs[msa];
  for (int j = tid; j < n; j += nt) v3[j] = SLT(tab, qp, rsa, rs[j], n2);
  if (Warp) __syncwarp(); else __syncthreads();
  for (int i = tid; i < n; i += nt) {
    rcx acc = rc(0.0, 0.0);
    for (int j = 0; j < n; ++j) acc = rc_sub(acc, rc_mul(invq[(size_t)j * n + i], v3[j]));
    v1[i] = acc;
  }
  if (Warp) __syncwarp(); else __syncthreads();
  // v3 is dead after the dot products. Share the identical reciprocal within
  // this warp instead of evaluating Smith division in every lane.
  rcx inv_vec1_a;
  if (Warp) {
    if (tid == 0) v3[0] = rc_div(rc(-1.0, 0.0), v1[msa]);
    __syncwarp();
    inv_vec1_a = v3[0];
  } else {
    inv_vec1_a = rc_div(rc(-1.0, 0.0), v1[msa]);
  }
  for (int i = tid; i < n; i += nt) v2[i] = rc_mul(invq[(size_t)msa * n + i], inv_vec1_a);
  if (tid == 0) *pfq = rc_mul(*pfq, rc_neg(v1[msa]));
  if (Warp) __syncwarp(); else __syncthreads();
  const int warp = tid >> 5, lane = tid & 31, nwarp = nt >> 5;
  for (int i = warp; i < n; i += nwarp) {
    const rcx vi1 = v1[i], vi2 = v2[i];
    for (int j = lane; j < n; j += 32) {
      const size_t e = (size_t)i * n + j;
      rcx x = rc_add(invq[e], rc_sub(rc_mul(vi1, v2[j]), rc_mul(v1[j], vi2)));
      if (j == msa) x = rc_sub(x, vi2);
      if (i == msa) x = rc_add(x, v2[j]);
      invq[e] = x;
    }
  }
  if (Warp) __syncwarp(); else __syncthreads();
}

// One block per walker. State per walker: ele [n], occ [2 nsite], inv
// [nqp][n*n] (invM = -X^-1), pf [nqp], aw (accepts since rebuild), logip
// (log|ip| with the 1e-100 floor). Dynamic shared memory: aligned n ints,
// nqp complex candidate Pfaffians, 3n complex vectors per update group, 8 ints.
extern "C" __global__ void interval_complex_hop(
    int* ele, int* occ, rcx* inv, rcx* pf, int* aw, double* logip, const rcx* slater,
    const rcx* weights, const int* gutz, const int* jast, const double* params,
    const unsigned int* tape, int total_hops, int* hop_off, int n, int ne, int nsite, int nqp,
    int ngutz, int nproj, int* hops_done, int* rebuild, int* accepts, int* total_accepts,
    int* error, int* valid, rcx* fac, rcx* work, double exchange_fraction, int fsz,
    int spin_free, double flip_fraction) {
  if (*error) return;  // block-uniform; previous launch owns the error flag
  const int nt = blockDim.x;
  // Each warp owns a QP and its vectors. Per-element dot/update arithmetic
  // retains its original order; only independent planes run concurrently.
  const size_t warp_shared = ((n + 1) & ~1) * sizeof(int)
      + (nqp + 3 * (nt >> 5) * n) * sizeof(rcx) + 8 * sizeof(int);
  const bool warp_updates = n >= 64 && n <= 128 && nqp >= (nt >> 5)
      && warp_shared <= 48 * 1024;
  const int update_groups = warp_updates ? (nt >> 5) : 1;
  extern __shared__ char smem_raw[];
  int* rs = reinterpret_cast<int*>(smem_raw);
  rcx* pfnew = reinterpret_cast<rcx*>(rs + ((n + 1) & ~1));  // [nqp]
  rcx* scratch = pfnew + nqp;                                 // [3n]
  int* mvw = reinterpret_cast<int*>(scratch + 3 * (size_t)n * update_groups);  // [8]
  rcx* v1 = scratch;
  rcx* v2 = v1 + n;
  rcx* v3 = v2 + n;
  const int w = blockIdx.x, tid = threadIdx.x;
  const int n2 = 2 * nsite;
  int* ele_w = ele + (size_t)w * n;
  int* occ_w = occ + (size_t)w * 2 * nsite;
  rcx* inv_w = inv + (size_t)w * nqp * n * n;
  rcx* pf_w = pf + (size_t)w * nqp;
  int* valid_w = valid + (size_t)w * nqp;
  rcx* fac_w = fac + (size_t)w * nqp * n * n;
  rcx* work_w = work + (size_t)w * nqp * n * n;
  const unsigned int* tape_w = tape + (size_t)w * 5;
  const size_t tape_stride = 5 * (size_t)gridDim.x;
  const int split = fsz ? n : ne;
  __shared__ int s_rank, s_exchange, s_partner, s_from, s_to, s_pfrom, s_pto;
  __shared__ double s_log;
  if (tid == 0) {
    int all = 1;
    for (int q = 0; q < nqp; ++q) all &= valid_w[q] != 0;
    s_rank = all;
  }
  __syncthreads();
  double log_old = logip[w];
  int window = aw[w], advanced = 0, accepted = 0, need_rebuild = 0;
  if (tid == 0) mvw[6] = 0;
  const int start = hop_off[w];
  for (int hop = start; hop < total_hops; ++hop) {
    const unsigned int* t = tape_w + (size_t)hop * tape_stride;
    if (tid == 0) {
      // No local spins in complex mode (rejected on the host), so a local
      // spin flip proposal is always invalid.
      const ResidentMove m = resident_propose(t, ele_w, occ_w, nullptr, n, ne, nsite,
                                              exchange_fraction, flip_fraction, fsz, spin_free);
      s_exchange = m.exchange;
      s_partner = m.partner;
      s_from = m.from;
      s_to = m.to;
      s_pfrom = m.pfrom;
      s_pto = m.pto;
      mvw[0] = m.valid;
      mvw[1] = m.msa;
    }
    __syncthreads();
    const int msa = mvw[1];
    const int exchange = s_exchange, partner = s_partner;
    const int from = s_from, to = s_to, pfrom = s_pfrom, pto = s_pto;
    const int ri = from % nsite, rj = to % nsite;
    if (!mvw[0]) {
      __syncthreads();
      ++advanced;
      continue;
    }
    if (tid == 0) {
      ele_w[msa] = fsz ? to : rj;
      occ_w[from] = 0;
      occ_w[to] = 1;
      if (exchange) {
        ele_w[partner] = fsz ? pto : ri;
        occ_w[pfrom] = 0;
        occ_w[pto] = 1;
      }
    }
    __syncthreads();
    for (int j = tid; j < n; j += nt) rs[j] = ele_w[j] + (j >= split ? nsite : 0);
    __syncthreads();
    if (!s_rank || exchange) {
      // Full candidate Pfaffians of every plane (Julia cooperative_overlap!).
      for (int q = 0; q < nqp; ++q) {
        rc_gather(fac_w, rs, n, -1, -1, slater, q, n2);
        const rcx p = rc_block_pfaffian(fac_w, n, scratch, scratch + n);
        if (tid == 0) pfnew[q] = p;
      }
      __syncthreads();
    } else {
      // C CalculateNewPfM2: pfMNew = -pfM sum_j invM[a][j] sltE[a][j].
      const int lane = tid & 31, warp = tid >> 5, nwarp = nt >> 5;
      for (int q = warp; q < nqp; q += nwarp) {
        const rcx* inv_row = inv_w + (size_t)q * n * n + (size_t)msa * n;
        const rcx* row = slater + ((size_t)q * n2 + rs[msa]) * n2;
        rcx ratio = rc(0.0, 0.0);
        for (int j = lane; j < n; j += 32) ratio = rc_add(ratio, rc_mul(inv_row[j], row[rs[j]]));
        ratio = rc_warp_sum(ratio);
        if (lane == 0) pfnew[q] = rc_neg(rc_mul(ratio, pf_w[q]));
      }
      __syncthreads();
    }
    if (tid == 0) {
      rcx ip_new = rc(0.0, 0.0);
      for (int q = 0; q < nqp; ++q) ip_new = rc_add(ip_new, rc_mul(weights[q], pfnew[q]));
      const double log_new = log(rc_abs(ip_new) + 1e-100);
      // An exchange or an on-site FSZ spin flip keeps every counter.
      const double proj =
          exchange || ri == rj
              ? 0.0
              : interval_proj_delta(occ_w, nsite, ngutz, nproj, gutz, jast, params, ri, rj);
      const double logratio = 2.0 * (proj + log_new - log_old);
      const double u = (double)t[4] / 4294967296.0;
      const int accept = rc_finite(ip_new) && !rc_zero(ip_new) && log(u) < logratio;
      mvw[5] = accept;
      int singular = 0;
      if (accept && s_rank && !exchange) {
        for (int q = 0; q < nqp; ++q) singular |= !rc_finite(pfnew[q]) || rc_zero(pfnew[q]);
      }
      mvw[7] = accept && (singular || !s_rank || exchange);
      if (accept) {
        s_log = log_new;
      } else {
        ele_w[msa] = fsz ? from : ri;
        occ_w[from] = 1;
        occ_w[to] = 0;
        if (exchange) {
          ele_w[partner] = fsz ? pfrom : rj;
          occ_w[pfrom] = 1;
          occ_w[pto] = 0;
        }
      }
    }
    __syncthreads();
    if (mvw[5] && mvw[7]) {
      const int all =
          rc_refactor_walker(inv_w, pf_w, valid_w, rs, slater, n, nqp, n2, fac_w, work_w, scratch);
      if (tid == 0) {
        rcx ip = rc(0.0, 0.0);
        for (int q = 0; q < nqp; ++q) ip = rc_add(ip, rc_mul(weights[q], pf_w[q]));
        ++accepted;
        if (!rc_finite(ip) || rc_zero(ip)) {
          atomicCAS(error, 0, RESIDENT_REBUILD);
          mvw[6] = 2;
        } else {
          log_old = log(rc_abs(ip) + 1e-100);
          window = 0;
        }
        s_rank = all;
      }
      __syncthreads();
    } else if (mvw[5]) {
      if (warp_updates) {
        const int warp = tid >> 5;
        rcx* vectors = scratch + (size_t)warp * 3 * n;
        for (int q = warp; q < nqp; q += nt >> 5)
          interval_complex_update<true>(inv_w + (size_t)q * n * n, pf_w + q, slater, q, rs,
                                        n, n2, msa, vectors, vectors + n, vectors + 2 * n);
      } else {
        for (int q = 0; q < nqp; ++q)
          interval_complex_update<false>(inv_w + (size_t)q * n * n, pf_w + q, slater, q, rs,
                                         n, n2, msa, v1, v2, v3);
      }
      if (tid == 0) {
        log_old = s_log;
        ++accepted;
        if (++window > nsite) mvw[6] = 1;
      }
      __syncthreads();
    }
    ++advanced;
    if (mvw[6]) {
      need_rebuild = mvw[6] == 1;  // 2: in-kernel refactor failed and latched
      break;
    }
  }
  if (tid == 0) {
    hop_off[w] = start + advanced;
    hops_done[w] = advanced;
    rebuild[w] = need_rebuild;
    accepts[w] = accepted;
    total_accepts[w] += accepted;
    aw[w] = window;
    logip[w] = log_old;
  }
}

// Assemble the complex plane A = -S(rs, rs) of a requested walker and factor
// it with a paired panel factorization (n>=64) or the C-order reference.
// Failure paths retain the original PFAPACK status through a device-only fallback.
extern "C" __global__ void interval_complex_factor(
    const int* rebuild, const int* error, const int* ele, const Cx<double>* slater,
    Cx<double>* A, Cx<double>* W, Cx<double>* OUT, Cx<double>* PF, int* ST,
    int n, int ne, int nsite, int nqp) {
  const int plane = blockIdx.x, w = plane / nqp, q = plane % nqp;
  if (*error || !rebuild[w]) return;
  Cx<double>* a = A + (size_t)plane * n * n;
  const int* e = ele + (size_t)w * n;
  for (int index = threadIdx.x; index < n * n; index += blockDim.x) {
    const int i = index / n, j = index % n;
    const int ri = e[i] + (i >= ne ? nsite : 0);
    const int rj = e[j] + (j >= ne ? nsite : 0);
    a[index] = -SLT(slater, q, ri, rj, 2 * nsite);
  }
  __syncthreads();
  body_c64(A, W, OUT, PF, ST, n);
}

// interval_resident_commit with complex tables: publish a walker whose
// weighted overlap is finite and nonzero, with per-plane validity; a zero or
// nonfinite total latches the sticky error and keeps every previous table.
extern "C" __global__ void interval_complex_commit(
    const int* rebuild, int* error, const int* ST, const rcx* OUT, const rcx* PF,
    const rcx* weights, rcx* inv, rcx* pf, double* logip, int* aw, int* valid, int n, int nqp) {
  const int w = blockIdx.x;
  if (!rebuild[w]) return;
  __shared__ int good;
  __shared__ double log_overlap;
  if (threadIdx.x == 0) {
    rcx ip = rc(0.0, 0.0);
    for (int q = 0; q < nqp; ++q) ip = rc_add(ip, rc_mul(weights[q], PF[w * nqp + q]));
    good = rc_finite(ip) && !rc_zero(ip);
    log_overlap = log(rc_abs(ip) + 1e-100);
    if (!good) atomicCAS(error, 0, RESIDENT_REBUILD);
  }
  __syncthreads();
  if (!good) return;
  const size_t base = (size_t)w * nqp * n * n;
  for (size_t i = threadIdx.x; i < (size_t)nqp * n * n; i += blockDim.x)
    inv[base + i] = rc_neg(OUT[base + i]);
  for (int q = threadIdx.x; q < nqp; q += blockDim.x) {
    const rcx p = PF[w * nqp + q];
    pf[w * nqp + q] = p;
    valid[w * nqp + q] = ST[w * nqp + q] == 0 && rc_finite(p) && !rc_zero(p);
  }
  if (threadIdx.x == 0) {
    logip[w] = log_overlap;
    aw[w] = 0;
  }
}
